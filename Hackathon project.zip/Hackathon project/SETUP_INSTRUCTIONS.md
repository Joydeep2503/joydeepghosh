# 🚀 StayNest Chaos QA - Setup & Run Guide

## What's Fixed ✅
All ChatGPT errors have been corrected:
- ✅ `CSS.escape()` issue fixed
- ✅ Async/await properly implemented
- ✅ Ternary operator simplified
- ✅ Ready to run immediately

---

## Step 1: Extract the Zip
Unzip this file in VS Code or extract it to a folder.

---

## Step 2: Open Terminal in Project Root
```bash
cd path/to/Joydeep_hackathon_project
```

---

## Step 3: Install Dependencies
```bash
npm install
npx playwright install chromium
```
*This may take 2-3 minutes for Playwright*

---

## Step 4: (Optional) Add Your Groq API Key

1. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```

2. Open `.env` and add your Groq API key:
   ```env
   GROQ_API_KEY=your_actual_key_here
   GROQ_MODEL=openai/gpt-oss-120b
   ```

**Note:** This is optional! The demo works WITHOUT an API key using deterministic probes.

---

## Step 5: Start the Server
**Open Terminal 1:**
```bash
npm start
```

You should see:
```
Chaos Playground running at http://127.0.0.1:8080/chaos-playground/
```

---

## Step 6: Run the Autonomous QA Test
**Open Terminal 2 (keep Terminal 1 running):**
```bash
npm run qa
```

This will:
- Launch a browser (Chromium)
- Test the demo app
- Find intentional bugs
- Generate a report

*Test takes ~30-60 seconds*

---

## Step 7: Generate the HTML Report
**In Terminal 2 (after test completes):**
```bash
npm run report
```

---

## Step 8: View the Results
Open this file in your browser:
```
reports/chaos-report.html
```

You should see a beautiful report showing:
- Summary statistics
- Findings discovered
- Evidence and recommendations
- Severity levels (Critical, High, Medium, Low)

---

## ✨ Expected Output

The report will show at least:
- **"Invalid payment data accepted"** — The app accepts card number "123"
- **"Payment action produced a booking confirmation"** — State transition issues

Plus any additional findings from AI exploration (if Groq API is configured).

---

## Troubleshooting

### "Cannot find module..."
**Solution:** Run `npm install` again
```bash
npm install
npx playwright install chromium
```

### "Port 8080 already in use"
**Solution:** Use a different port
```bash
PORT=9000 npm start
```

### "innerText is not a function"
**Solution:** This should be fixed, but if it appears, your file wasn't replaced properly. 
→ Copy `tests/chaos.spec.js` from the outputs folder again.

### "GROQ_API_KEY not found"
**Solution:** This is fine! The demo works without it. Add it to `.env` only if you want full AI exploration.

### Playwright installation fails
**Solution:** Install manually:
```bash
npx playwright install chromium --with-deps
```

---

## Project Structure

```
Joydeep_hackathon_project/
├── chaos-playground/           # The demo web app
│   └── index.html             # Intentionally buggy booking app
├── agents/
│   ├── ai.js                  # Groq API integration
│   └── heuristics.js          # Bug detection logic
├── tests/
│   └── chaos.spec.js          # ✅ FIXED Playwright test
├── scripts/
│   └── generate-report.js     # Report generator
├── prompts/
│   └── chaos-agent.txt        # AI instructions
├── reports/                   # Output folder (created after running)
├── server.js                  # Express server
├── package.json               # Dependencies
└── .env.example               # API key template
```

---

## What Happens When You Run It?

1. **Server starts** - Serves the buggy web app on localhost:8080
2. **Browser launches** - Playwright opens Chromium silently
3. **Navigation** - Goes through: Search → Select Stay → Guest Details → Payment
4. **Boundary probes** - Intentionally sends invalid card data to trigger bugs
5. **AI exploration** (if API key configured) - LLM chooses additional exploratory actions
6. **Report generation** - Creates `reports/chaos-report.json`
7. **HTML rendering** - Converts to pretty HTML report

---

## Demo Flow Explained

The app demonstrates:
- ✅ Realistic booking UI (Airbnb-style)
- ✅ Multi-step checkout flow
- ❌ **BUG #1:** Accepts invalid card numbers (< 12 digits)
- ❌ **BUG #2:** Can process payment twice
- ✅ Deterministic detection (always finds these bugs)
- ✅ AI-assisted exploration (finds additional issues if API available)

---

## Next Steps After Getting Output

1. **Study the findings** - See what bugs were detected
2. **Check evidence** - Review what actions triggered each bug
3. **View recommendations** - Fix suggestions for each finding
4. **Tweak the app** - Modify `chaos-playground/index.html` to fix bugs, re-run
5. **Test with API key** - Add Groq key for more advanced AI exploration

---

## Important Notes

- 🔒 No real payments are processed (this is a demo)
- 🤖 The AI agent requires a Groq API key (optional for basic tests)
- 📊 Reports are saved in `reports/` folder
- 🌐 The app only runs locally (127.0.0.1:8080)
- ⏱️ Tests are fast (~30-60 seconds)

---

## Support

If you hit any issues:
1. Check Troubleshooting section above
2. Verify all dependencies installed: `npm list`
3. Check Node version: `node --version` (should be 14+)
4. Review test output in terminal for error messages

---

**Good luck with your hackathon! 🎉**
