"""
AI Chaos QA - Streamlit frontend
----------------------------------
Run with: streamlit run frontend/app.py

Thin client over the autonomous FastAPI backend. There is no manual endpoint
configuration or scenario selection here on purpose - point it at a target
and the backend agent discovers endpoints, decides which chaos scenarios
apply, runs them, and generates the report by itself.
"""
import time

import requests
import streamlit as st

st.set_page_config(page_title="AI Chaos QA", page_icon="🧪", layout="wide")

if "api_base" not in st.session_state:
    st.session_state.api_base = "http://localhost:8000"
if "run_id" not in st.session_state:
    st.session_state.run_id = None
if "target_url" not in st.session_state:
    st.session_state.target_url = "http://localhost:9000"

API_BASE = st.session_state.api_base


def api_get(path, **kwargs):
    return requests.get(f"{API_BASE}{path}", **kwargs)


def api_post(path, **kwargs):
    return requests.post(f"{API_BASE}{path}", **kwargs)


STATUS_LABELS = {
    "discovering": "🔎 Discovering endpoints (OpenAPI)...",
    "planning": "🧠 AI is deciding which scenarios to run...",
    "running": "🟡 Executing chaos scenarios...",
    "recovering": "💉 Injecting fault & monitoring recovery...",
    "analyzing_recovery": "🧠 AI is explaining the fault & recovery...",
    "analyzing": "🧠 AI is analyzing results...",
    "completed": "🟢 Completed",
    "failed": "🔴 Failed",
}
IN_PROGRESS_STATUSES = {"discovering", "planning", "running", "recovering", "analyzing_recovery", "analyzing"}

# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------
st.sidebar.title("🧪 AI Chaos QA")
st.sidebar.caption("Fully autonomous: the agent discovers endpoints, decides scenarios, runs them, and reports back.")

api_base_input = st.sidebar.text_input("Backend API URL", value=API_BASE)
if api_base_input != API_BASE:
    st.session_state.api_base = api_base_input
    st.rerun()

st.sidebar.subheader("Target")
target_url = st.sidebar.text_input(
    "Target URL",
    value=st.session_state.target_url,
    help=(
        "Either a FastAPI service base URL (e.g. http://localhost:9000 - discovered via "
        "/openapi.json) or any plain URL with no API spec (e.g. https://www.example.com/page). "
        "The tool detects automatically which mode to use."
    ),
)
st.session_state.target_url = target_url

verify_ssl = st.sidebar.checkbox(
    "Verify SSL certificates",
    value=True,
    help=(
        "Turn OFF if you get SSLCertVerificationError - common on corporate networks with a "
        "TLS-inspecting proxy. Only disable for targets you trust."
    ),
)
if not verify_ssl:
    st.sidebar.caption("⚠️ SSL verification disabled - traffic could be intercepted. Use only on trusted networks/targets.")

if st.sidebar.button("🔍 Preview discovered endpoints"):
    try:
        r = api_get("/api/discover", params={"target_url": target_url, "verify_ssl": verify_ssl})
        r.raise_for_status()
        data = r.json()
        mode_label = "structured API (OpenAPI found)" if data["mode"] == "openapi" else "generic URL (no OpenAPI spec found)"
        st.sidebar.success(f"Found {data['endpoint_count']} endpoint(s) — mode: {mode_label}.")
        st.sidebar.caption(f"Requests will be sent to: `{data['effective_base_url']}`")
        with st.sidebar.expander("Discovered endpoints", expanded=True):
            for e in data["endpoints"]:
                body = " (has body)" if e["sample_payload"] else ""
                st.write(f"`{e['method']} {e['path']}`{body}")
    except Exception as exc:
        st.sidebar.error(f"Discovery failed: {exc}")

if st.sidebar.button("🚀 Run Autonomous Chaos Test", type="primary", use_container_width=True):
    try:
        r = api_post("/api/runs/autostart", json={"target_url": target_url, "verify_ssl": verify_ssl})
        r.raise_for_status()
        st.session_state.run_id = r.json()["run_id"]
        st.sidebar.success(f"Run #{st.session_state.run_id} started!")
    except Exception as exc:
        st.sidebar.error(f"Failed to start run: {exc}")

# ---------------------------------------------------------------------------
# Main content
# ---------------------------------------------------------------------------
st.title("AI Chaos QA")
st.caption(
    "An autonomous resilience-testing agent: discovers the target API's endpoints, "
    "decides for itself which chaos scenarios apply, injects controlled faults, "
    "observes behavior in real time, and generates an AI resilience report."
)

tab_live, tab_recovery, tab_report, tab_history = st.tabs(
    ["🔴 Live Run & Results", "💉 Fault Injection & Recovery", "📋 AI Report", "🗂️ Run History"]
)

# --- Live Run & Results ------------------------------------------------
with tab_live:
    if not st.session_state.run_id:
        st.info("Enter a target URL and click **Run Autonomous Chaos Test** in the sidebar to begin.")
    else:
        run_id = st.session_state.run_id
        col1, col2 = st.columns([3, 1])
        with col2:
            auto_refresh = st.checkbox("Auto-refresh (2s)", value=True)
            manual_refresh = st.button("Refresh now")

        try:
            run_resp = api_get(f"/api/runs/{run_id}")
            run_resp.raise_for_status()
            run_info = run_resp.json()
        except Exception as exc:
            st.error(f"Could not load run: {exc}")
            run_info = None

        if run_info:
            status = run_info["status"]
            st.subheader(f"Run #{run_id} — {STATUS_LABELS.get(status, status)}")
            if run_info.get("error"):
                st.error(run_info["error"])

            plan = run_info.get("plan")
            if plan:
                mode_note = " _(generic URL - no OpenAPI spec found)_" if plan.get("discovery_mode") == "generic" else ""
                source_note = " _(fallback rules used - Ollama unavailable)_" if plan.get("source") == "fallback" else ""
                st.markdown(f"**🧠 AI's scenario plan**{mode_note}{source_note}")
                st.write(f"Scenarios chosen: {', '.join(plan['scenarios'])}")
                st.write(f"Chaos hook detected: `{plan['chaos_hook_path']}`" if plan.get("chaos_hook_path") else "Chaos hook detected: none")
                st.caption(plan.get("rationale", ""))
                endpoints = run_info.get("endpoints") or []
                if endpoints:
                    with st.expander(f"Endpoints discovered ({len(endpoints)})"):
                        for e in endpoints:
                            body = " (has body)" if e["sample_payload"] else ""
                            st.write(f"`{e['method']} {e['path']}`{body}")

            results_resp = api_get(f"/api/runs/{run_id}/results")
            results = results_resp.json() if results_resp.ok else []

            total = len(results)
            anomalies = sum(1 for r in results if r["is_anomaly"])
            m1, m2, m3 = st.columns(3)
            m1.metric("Tests executed", total)
            m2.metric("Anomalies found", anomalies)
            m3.metric("Anomaly rate", f"{(anomalies/total*100):.0f}%" if total else "0%")

            if results:
                import pandas as pd
                df = pd.DataFrame(results)[
                    ["scenario", "endpoint", "method", "test_case", "status_code",
                     "response_time_ms", "is_anomaly", "anomaly_reason"]
                ]
                df["is_anomaly"] = df["is_anomaly"].map({1: "⚠️ Yes", 0: "OK"})
                st.dataframe(df, use_container_width=True, height=350)

                c1, c2 = st.columns(2)
                with c1:
                    st.caption("Status code distribution")
                    code_counts = df["status_code"].fillna("no response").astype(str).value_counts()
                    st.bar_chart(code_counts)
                with c2:
                    st.caption("Response time (ms) per test")
                    st.bar_chart(df["response_time_ms"].fillna(0))
            elif status not in ("discovering", "planning"):
                st.write("No results yet...")

            if status not in ("completed", "failed") and (auto_refresh or manual_refresh):
                time.sleep(2)
                st.rerun()
            elif manual_refresh:
                st.rerun()

# --- Fault Injection & Recovery --------------------------------------------
with tab_recovery:
    if not st.session_state.run_id:
        st.info("Run an autonomous chaos test first - this tab fills in once the agent starts the recovery phase.")
    else:
        run_id = st.session_state.run_id
        try:
            run_resp = api_get(f"/api/runs/{run_id}")
            run_info = run_resp.json() if run_resp.ok else {}
        except Exception:
            run_info = {}
        status = run_info.get("status")

        if status in ("discovering", "planning", "running"):
            st.info("Waiting for the chaos scenarios to finish before the recovery phase starts...")
            time.sleep(2)
            st.rerun()
        else:
            try:
                rec_resp = api_get(f"/api/runs/{run_id}/recovery")
                rec_data = rec_resp.json() if rec_resp.ok else {"events": [], "summary": None}
            except Exception as exc:
                st.error(f"Could not load recovery data: {exc}")
                rec_data = {"events": [], "summary": None}

            events = rec_data.get("events") or []
            summary = rec_data.get("summary")

            if not events:
                st.info("No GET endpoint was available to safely poll repeatedly, so recovery monitoring was skipped for this target.")
            else:
                endpoint = events[0]["endpoint"]
                fault_type = next((e["fault_type"] for e in events if e["fault_type"] not in ("-", None)), "-")
                st.subheader(f"Target: `{endpoint}`")
                st.caption(
                    "Fault type: **chaos hook toggle**" if fault_type == "chaos_hook_toggle"
                    else "Fault type: **concurrent load burst** (no chaos hook was found on this target)"
                )

                if summary:
                    if summary["outcome"] == "recovered":
                        st.success(
                            f"✅ Recovered after **{summary['recovery_time_ms']/1000:.1f}s** "
                            f"({summary['total_attempts']} poll attempt(s))"
                        )
                    else:
                        st.error(
                            f"❌ Did not recover within the monitoring window "
                            f"({summary['total_attempts']} poll attempt(s))"
                        )
                elif status == "recovering":
                    st.warning("🔁 Fault injected — polling live until the endpoint recovers...")
                elif status == "analyzing_recovery":
                    st.info("🧠 Recovered — AI is now explaining what happened...")

                # Live timeline
                import pandas as pd
                df = pd.DataFrame(events)[
                    ["phase", "attempt_number", "elapsed_ms_since_fault", "status_code",
                     "response_time_ms", "is_healthy", "note"]
                ]
                df["is_healthy"] = df["is_healthy"].map({1: "✅ healthy", 0: "⚠️ unhealthy"})
                st.dataframe(df, use_container_width=True, height=300)

                recovering_rows = [e for e in events if e["phase"] == "recovering"]
                if recovering_rows:
                    chart_df = pd.DataFrame(recovering_rows).set_index("elapsed_ms_since_fault")
                    st.caption("Response time (ms) during recovery polling, by time since fault cleared (ms)")
                    st.line_chart(chart_df["response_time_ms"])

                # AI reasoning
                if summary:
                    st.markdown("### 🧠 AI Analysis: why it went down & how it recovered")
                    st.write(f"**Root cause:** {summary['root_cause']}")
                    st.write(f"**Recovery:** {summary['recovery_explanation']}")
                    if summary.get("recommendations"):
                        st.markdown("**Recommendations:**")
                        for rec in summary["recommendations"]:
                            st.markdown(f"- ✅ {rec}")

                if status in ("recovering", "analyzing_recovery"):
                    time.sleep(2)
                    st.rerun()

# --- AI Report -----------------------------------------------------------
with tab_report:
    if not st.session_state.run_id:
        st.info("Run an autonomous chaos test first - the report is generated automatically when it finishes.")
    else:
        run_id = st.session_state.run_id
        run_resp = api_get(f"/api/runs/{run_id}")
        run_info = run_resp.json() if run_resp.ok else {}
        status = run_info.get("status")

        if status in ("discovering", "planning", "running", "analyzing"):
            st.info(f"{STATUS_LABELS.get(status, status)} The report will appear here automatically once the run completes.")
            time.sleep(2)
            st.rerun()
        elif status == "failed":
            st.error("This run failed, so no report was generated. See the error on the Live Run tab.")
        else:
            report = None
            try:
                r = api_get(f"/api/runs/{run_id}/report")
                if r.ok:
                    report = r.json()
            except Exception as exc:
                st.error(f"Failed to load report: {exc}")

            if report:
                if st.button("🔄 Force regenerate report"):
                    with st.spinner("Asking the local LLM (Ollama) to re-analyze results..."):
                        r = api_get(f"/api/runs/{run_id}/report", params={"regenerate": True})
                        if r.ok:
                            report = r.json()

                st.metric("Resilience Score", f"{report['resilience_score']:.0f} / 100")
                st.subheader("Summary")
                st.write(report["summary"])

                st.subheader("Findings")
                for f in report["findings"] or ["No findings."]:
                    st.markdown(f"- ⚠️ {f}")

                st.subheader("Recommendations")
                for rec in report["recommendations"] or ["No recommendations."]:
                    st.markdown(f"- ✅ {rec}")
            else:
                st.write("No report available yet.")

# --- Run History -----------------------------------------------------------
with tab_history:
    try:
        runs_resp = api_get("/api/runs")
        runs = runs_resp.json() if runs_resp.ok else []
    except Exception as exc:
        st.error(f"Could not load history: {exc}")
        runs = []

    if not runs:
        st.info("No runs yet.")
    else:
        for r in runs:
            with st.container(border=True):
                c1, c2, c3, c4 = st.columns([1, 3, 2, 2])
                c1.write(f"**#{r['id']}**")
                c2.write(r["target_url"])
                c3.write(STATUS_LABELS.get(r["status"], r["status"]))
                c4.write((r.get("started_at") or "")[:19].replace("T", " "))
                if r.get("plan"):
                    st.caption(f"Scenarios: {', '.join(r['plan']['scenarios'])}")
                if st.button("View", key=f"view_{r['id']}"):
                    st.session_state.run_id = r["id"]
                    st.rerun()
