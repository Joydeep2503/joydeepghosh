"""
Orchestrator
------------
The single autonomous pipeline the FastAPI backend kicks off in the
background for every run:

  discover endpoints (OpenAPI) -> AI decides scenarios -> execute chaos
  scenarios -> AI generates the resilience report -> done

Each phase updates the run's status in SQLite so the frontend can show
exactly what the agent is doing in real time.
"""
from backend import database as db
from backend import discovery
from backend import ai_planner
from backend import chaos_engine
from backend import ai_analyzer


def autonomous_run(run_id, target_url, verify_ssl=True):
    try:
        # 1. AI Injects Failure (prep step: discover what's even testable).
        # Works against both structured APIs (OpenAPI discovery) and plain
        # URLs with no API spec (generic single-URL fallback) - see
        # discovery.py. This can never raise "no endpoints" since generic
        # mode always returns at least the target URL itself.
        db.update_status(run_id, "discovering")
        endpoints, discovery_mode, effective_base_url = discovery.discover_endpoints(
            target_url, verify_ssl=verify_ssl
        )

        # AI decides which scenarios apply to this specific target
        db.update_status(run_id, "planning")
        plan = ai_planner.plan_scenarios(target_url, endpoints, discovery_mode)
        plan["discovery_mode"] = discovery_mode
        plan["effective_base_url"] = effective_base_url
        db.set_run_plan(run_id, plan, endpoints)

        # 2 & 3. AI Observes Behavior / AI Validates Resilience
        db.update_status(run_id, "running")
        chaos_engine.execute_run(
            run_id, effective_base_url, plan["scenarios"], endpoints,
            plan.get("chaos_hook_path"), verify_ssl=verify_ssl,
        )

        # 4 & 5. AI Identifies Weaknesses / AI Generates Reports
        db.update_status(run_id, "analyzing")
        ai_analyzer.generate_report(run_id)

        db.finish_run(run_id, status="completed")
    except Exception as exc:  # noqa: BLE001
        db.finish_run(run_id, status="failed", error=str(exc))
