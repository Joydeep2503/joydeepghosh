type ActionHistoryEntry = {
  step: number;
  action: string;
  targetId?: string;
  value?: string;
  result: string;
};

export function buildPrompt(
  pageData: any,
  actionHistory: ActionHistoryEntry[] = [],
  previouslyUsed: string[] = []
): string {
  const compactPageData = {
    title: pageData.title,
    url: pageData.url,
    elements: (pageData.elements || []).slice(0, 100).map((e: any) => ({
      id: e.id,
      tag: e.tag,
      type: e.type || "",
      text: e.text ? String(e.text).trim().slice(0, 80) : "",
      name: e.name ? String(e.name).slice(0, 40) : "",
      placeholder: e.placeholder ? String(e.placeholder).slice(0, 50) : "",
      value: e.value ? String(e.value).slice(0, 40) : "",
      href: e.href ? String(e.href).slice(0, 120) : "",
    })),
  };
  const compactHistory = actionHistory.slice(-15).map((entry) => ({
    step: entry.step,
    action: entry.action,
    targetId: entry.targetId || "",
    value: entry.value || "",
    result: entry.result,
  }));

  return `You are an autonomous exploratory QA agent. Choose ONE new, safe action.
Explore user journeys first, then boundary states (empty, min/max, malformed,
rapid repeat, and stale state). Ordinary required-field validation is expected,
not a defect.

Rules:
- Use only the exact id in CURRENT PAGE DATA. Never invent an id, selector,
  XPath, text selector, value, or URL.
- Choose click for buttons/links, fill for inputs/textareas, select for selects.
- Use goto only with an exact href in the page data.
- Never repeat an action signature already in PREVIOUS ACTIONS:
  action + targetId + value. If it failed, choose another target.
- An edge case needs a boundary, unusual sequence, state inconsistency, crash,
  data loss, security issue, or behavior contradicting the UI contract.
- If all useful actions are exhausted, return stop. Return JSON only.

Allowed actions: click, doubleClick, fill, select, hover, scroll, wait,
goBack, goForward, reload, none, stop.
For fill/select choose a compact boundary value or realistic valid value based
on the field. Output exactly:
{"action":"click|fill|select|goto|reload|back|forward|none|stop",
 "targetId":"","value":"","reason":"brief reason"}

CURRENT PAGE DATA:
${JSON.stringify(compactPageData)}
PREVIOUS ACTIONS:
${JSON.stringify(compactHistory)}
PREVIOUSLY USED ON THIS PAGE:
${JSON.stringify(previouslyUsed.slice(-100))}
Never choose a signature from PREVIOUSLY USED ON THIS PAGE.`;
}