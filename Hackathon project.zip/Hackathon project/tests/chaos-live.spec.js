import { test } from "@playwright/test";
import fs from "fs";
import path from "path";
import { askAgent } from "../agents/ai.js";
import { analyzeObservation } from "../agents/heuristics.js";
const APP_URL = process.env.APP_URL || "http://127.0.0.1:8080/chaos-playground/";
const MAX_ACTIONS = Number(process.env.MAX_AI_ACTIONS || 8);
const OUT = path.resolve("reports");
function ensureReports() {
    fs.mkdirSync(OUT, { recursive: true });
}
async function domSnapshot(page) {
    try {
        return await page.locator("body").innerText();
    } catch {
        return "";
    }
}
async function describeTargets(page) {
    return page.locator("button,input,select,a").evaluateAll(els =>
        els.map((e, i) => ({
            id: e.id || e.getAttribute("data-testid") || `element-${i}`,
            tag: e.tagName.toLowerCase(),
            text: (e.innerText || e.getAttribute("aria-label") || e.getAttribute("placeholder") || "").trim().slice(0, 100),
            type: e.getAttribute("type"),
            value: e.value || ""
        })).slice(0, 80)
    );
}
// ✨ NEW: Add visual indicator to show what action was performed
async function highlightAction(page, targetId) {
    try {
        await page.evaluate((id) => {
            const el = document.getElementById(id);
            if (el) {
                el.style.boxShadow = "0 0 10px 3px #e11d48, 0 0 20px 6px rgba(225, 29, 72, 0.5)";
                el.style.transition = "all 0.3s ease";
            }
        }, targetId);
        // Add floating label showing current action
        await page.evaluate(() => {
            const label = document.createElement("div");
            label.id = "ai-action-indicator";
            label.style.cssText = `
       position: fixed;
       top: 20px;
       right: 20px;
       background: #e11d48;
       color: white;
       padding: 12px 16px;
       border-radius: 8px;
       font-weight: bold;
       font-size: 14px;
       z-index: 9999;
       box-shadow: 0 4px 12px rgba(0,0,0,0.3);
       animation: pulse 1s infinite;
     `;
            label.textContent = "🤖 AI ACTION IN PROGRESS...";
            document.body.appendChild(label);
            const style = document.createElement("style");
            style.textContent = `
       @keyframes pulse {
         0% { transform: scale(1); }
         50% { transform: scale(1.05); }
         100% { transform: scale(1); }
       }
     `;
            document.head.appendChild(style);
        });
        await page.waitForTimeout(300);
    } catch (e) {
        // Silently fail if highlight doesn't work
    }
}
// ✨ NEW: Remove visual indicator
async function clearIndicator(page) {
    try {
        await page.evaluate(() => {
            const label = document.getElementById("ai-action-indicator");
            if (label) label.remove();
            const els = document.querySelectorAll("[style*='boxShadow']");
            els.forEach(el => {
                if (el.style.boxShadow && el.style.boxShadow.includes("e11d48")) {
                    el.style.boxShadow = "";
                }
            });
        });
    } catch (e) {
        // Silently fail
    }
}
async function execute(page, action) {
    if (!action || !action.action || action.action === "none" || action.action === "stop") return false;
    const targets = await describeTargets(page);
    const target = targets.find(x => x.id === action.targetId);
    if (!target) return false;
    const locator = page.locator(`#${target.id}`);
    // ✨ Show what we're about to do
    await highlightAction(page, target.id);
    console.log(`   → Executing ${action.action} on ${target.id}...`);
    if (action.action === "click") await locator.click({ timeout: 5000 });
    else if (action.action === "fill" && target.tag === "input") await locator.fill(String(action.value ?? ""));
    else if (action.action === "press") await locator.press(String(action.value || "Enter"));
    else if (action.action === "select" && target.tag === "select") await locator.selectOption(String(action.value));
    else return false;
    // Wait a bit so you can see the change
    await page.waitForTimeout(600);
    await clearIndicator(page);
    return true;
}
test("Autonomous AI Chaos QA — LIVE MODE 🎬", async ({ page }) => {
    ensureReports();
    const observations = [];
    const findings = [];
    // ✨ Show initial action
    console.log("\n🎬 CHAOS QA TEST STARTING (LIVE MODE)");
    console.log("📺 Watch the browser window to see AI actions in real-time!");
    console.log("═".repeat(60));
    await page.goto(APP_URL);
    await page.waitForLoadState("domcontentloaded");
    console.log("\n📍 STEP 1: Seeding into payment flow...");
    await page.locator("#filter-all").click();
    await page.waitForTimeout(500);
    await page.locator(".book-btn").first().click();
    await page.waitForTimeout(500);
    await page.locator("#to-payment").click();
    await page.waitForTimeout(500);
    console.log("✅ Payment page loaded\n");
    // Deterministic boundary probes
    console.log("🔍 DETERMINISTIC PROBES (2/2 - Always same, but always finds bugs)");
    console.log("─".repeat(60));
    const probes = [
        async () => {
            console.log("\n[PROBE 1] Testing invalid card number (123)...");
            const before = await domSnapshot(page), urlBefore = page.url();
            await highlightAction(page, "card");
            console.log("   → Filling card with '123'");
            await page.locator("#card").fill("123");
            await page.waitForTimeout(600);
            await highlightAction(page, "expiry");
            console.log("   → Filling expiry with '01/20'");
            await page.locator("#expiry").fill("01/20");
            await page.waitForTimeout(600);
            await highlightAction(page, "cvv");
            console.log("   → Filling CVV with '1'");
            await page.locator("#cvv").fill("1");
            await page.waitForTimeout(600);
            await highlightAction(page, "pay-btn");
            console.log("   → Clicking PAY button");
            await page.locator("#pay-btn").click();
            await page.waitForTimeout(800);
            const after = await domSnapshot(page), urlAfter = page.url();
            await clearIndicator(page);
            const action = { action: "fill", targetId: "card", value: "123", reason: "Boundary probe: deliberately invalid card data." };
            observations.push({ action, before: before.slice(-2500), after: after.slice(-2500), urlBefore, urlAfter });
            findings.push(...analyzeObservation({ before, after, action, urlBefore, urlAfter }));
            if (await page.locator("#back-home").count()) {
                console.log("   ⚠️  Bug found! App accepted invalid card 123");
                console.log("   🔄 Resetting to payment page...");
                await page.goto(APP_URL);
                await page.locator(".book-btn").first().click();
                await page.locator("#to-payment").click();
                await page.waitForTimeout(500);
            }
            console.log("✅ Probe 1 complete\n");
        },
        async () => {
            console.log("[PROBE 2] Testing valid card number (4111111111111111)...");
            const before = await domSnapshot(page), urlBefore = page.url();
            await highlightAction(page, "card");
            console.log("   → Filling card with '4111111111111111'");
            await page.locator("#card").fill("4111111111111111");
            await page.waitForTimeout(600);
            await highlightAction(page, "expiry");
            console.log("   → Filling expiry with '12/30'");
            await page.locator("#expiry").fill("12/30");
            await page.waitForTimeout(600);
            await highlightAction(page, "cvv");
            console.log("   → Filling CVV with '123'");
            await page.locator("#cvv").fill("123");
            await page.waitForTimeout(600);
            await highlightAction(page, "pay-btn");
            console.log("   → Clicking PAY button");
            await page.locator("#pay-btn").click();
            const after = await domSnapshot(page), urlAfter = page.url();
            await clearIndicator(page);
            const action = { action: "click", targetId: "pay-btn", value: null, reason: "Repeated-submission probe on payment control." };
            observations.push({ action, before: before.slice(-2500), after: after.slice(-2500), urlBefore, urlAfter });
            findings.push(...analyzeObservation({ before, after, action, urlBefore, urlAfter }));
            console.log("✅ Probe 2 complete\n");
        }
    ];
    for (const probe of probes) await probe();
    // AI exploration
    console.log("\n🤖 AI EXPLORATION (Up to 6 actions - Random based on LLM)");
    console.log("─".repeat(60));
    console.log(`API Key present: ${process.env.GROQ_API_KEY ? "✅ YES" : "❌ NO"}\n`);
    for (let i = 0; i < MAX_ACTIONS; i++) {
        const before = await domSnapshot(page);
        const targets = await describeTargets(page);
        const prompt = fs.readFileSync("prompts/chaos-agent.txt", "utf8") +
            `\n\nCURRENT URL:\n${page.url()}\n\nRECENT UI TEXT:\n${before.slice(-6000)}\n\nAVAILABLE TARGETS:\n${JSON.stringify(targets)}`;
        console.log(`[AI ACTION ${i + 1}/${MAX_ACTIONS}] Asking LLM what to do next...`);
        const action = await askAgent(prompt);
        if (!action) {
            console.log(`❌ AI returned null (API unavailable or rate limited)\n`);
            break;
        }
        if (action.action === "stop" || action.action === "none") {
            console.log(`⏹️  AI decided to stop exploring\n`);
            break;
        }
        console.log(`✨ AI chose: ${action.action.toUpperCase()} on ${action.targetId}`);
        console.log(`   Reason: ${action.reason}`);
        const urlBefore = page.url();
        const executed = await execute(page, action);
        if (!executed) {
            console.log(`❌ Target not found, skipping...\n`);
            continue;
        }
        console.log(`✅ Action executed successfully`);
        await page.waitForTimeout(300);
        const after = await domSnapshot(page);
        const urlAfter = page.url();
        observations.push({
            action,
            before: before.slice(-2500),
            after: after.slice(-2500),
            urlBefore,
            urlAfter
        });
        const actionFindings = analyzeObservation({ before, after, action, urlBefore, urlAfter });
        if (actionFindings.length > 0) {
            console.log(`🐛 Found ${actionFindings.length} bug(s) from this action!\n`);
        } else {
            console.log(`✓ No issues found from this action\n`);
        }
        findings.push(...actionFindings);
    }
    console.log("\n" + "═".repeat(60));
    console.log("📊 GENERATING REPORT...");
    // De-duplicate findings
    const unique = [...new Map(findings.map(f => [`${f.title}|${f.category}`, f])).values()];
    const report = {
        generatedAt: new Date().toISOString(),
        appUrl: APP_URL,
        summary: {
            actions: observations.length,
            observations: observations.length,
            chaosFindings: unique.length,
            edgeCases: unique.filter(f => f.category !== "NAVIGATION").length
        },
        findings: unique,
        observations
    };
    fs.writeFileSync(path.join(OUT, "chaos-report.json"), JSON.stringify(report, null, 2));
    console.log(`\n🎉 TEST COMPLETE!`);
    console.log(`   Total actions: ${observations.length}`);
    console.log(`   Bugs found: ${unique.length}`);
    console.log(`   Report saved: reports/chaos-report.json`);
    console.log(`   HTML report: reports/chaos-report.html`);
    console.log("═".repeat(60) + "\n");
});