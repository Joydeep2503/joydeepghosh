import { test } from "@playwright/test";
import fs from "node:fs/promises";
import path from "node:path";
import { extractPageData } from "../utils/domExtractor";
import { buildPrompt } from "../prompts/uiPrompt";
import { askGroq } from "../agents/llm";
import { executeAction } from "../utils/actionExecutor";
import {
  analyzeChaos,
  type ChaosObservation,
} from "../utils/chaosAnalyzer";
import {
  generateChaosReports,
  type ChaosReport,
} from "../utils/reportGenerator";
test.setTimeout(180_000);
type AIAction = {
  action: string;
  targetId?: string;
  value?: string;
  reason?: string;
};
const MAX_STEPS = Number(
  process.env.MAX_STEPS || 5
);
test(
  "Autonomous AI Chaos QA",
  async ({ page }) => {
    const targetUrl =
      process.env.TARGET_URL ||
      "http://127.0.0.1:8080/chaos-playground/";
    console.log(
      "\n=================================================="
    );
    console.log(
      "🤖 AUTONOMOUS AI CHAOS QA"
    );
    console.log(
      "=================================================="
    );
    console.log(
      `🌐 Target: ${targetUrl}`
    );
    console.log(
      `🔢 Maximum AI steps: ${MAX_STEPS}`
    );
    console.log(
      "==================================================\n"
    );
    const reports: ChaosReport[] = [];
    const actionHistory: Array<{
      step: number;
      action: string;
      targetId?: string;
      value?: string;
      result: string;
    }> = [];
    const explorationHistory: ChaosObservation[] = [];
    try {
      await page.goto(targetUrl, {
        waitUntil: "domcontentloaded",
        timeout: 60_000,
      });
      console.log("✅ Page loaded");
    } catch (error) {
      console.error(
        "❌ Navigation failed"
      );
      console.error(error);
      await page.screenshot({
        path:
          "screenshots/navigation-failure.png",
        fullPage: true,
      });
      throw error;
    }
    for (
      let step = 1;
      step <= MAX_STEPS;
      step++
    ) {
      console.log(
        `\n\n================ STEP ${step} ================`
      );
      /*
       * 1. Extract current DOM
       */
      const pageData =
        await extractPageData(page);
      console.log(
        "📄 DOM extracted"
      );
      /*
       * 2. Build AI prompt
       */
      const prompt = buildPrompt(pageData, actionHistory);
      console.log("🤖 AI prompt created");
      const aiResponse = await askGroq(prompt);
      console.log("\n🤖 AI RESPONSE");
      console.log(aiResponse);
      console.log(
        "\n🤖 AI RESPONSE"
      );
      console.log(aiResponse);
      /*
       * 4. Parse AI response
       */
      let decision: AIAction;
      try {
        decision =
          JSON.parse(aiResponse);
      } catch (error) {
        console.error(
          "⚠️ AI returned invalid JSON."
        );
        console.error(
          aiResponse
        );
        continue;
      }
      console.log(
        "\n🎯 AI DECISION"
      );
      console.log(
        JSON.stringify(
          decision,
          null,
          2
        )
      );
      /*
       * 5. Stop condition
       */
      if (
        !decision.action ||
        decision.action === "none" ||
        decision.action === "stop"
      ) {
        console.log(
          "\n🛑 AI decided to stop exploration."
        );
        break;
      }
      /*
       * 6. Capture page state before action
       */
      const beforeUrl =
        page.url();
      const beforeTitle =
        await page.title().catch(
          () => ""
        );
      /*
       * 7. Execute AI-selected action
       */
      let executionError = "";
      let executionResult:
        | unknown
        | undefined;
      try {
        console.log(
          `\n⚡ Executing AI action: ${decision.action}`
        );
        const validTarget =
          decision.targetId &&
          pageData.elements.some(
            (element: any) =>
              element.id === decision.targetId
          );
        if (
          decision.action !== "none" &&
          decision.action !== "stop" &&
          !validTarget
        ) {
          executionError =
            `Invalid targetId returned by AI: ${decision.targetId}`;
          console.warn(
            `⚠️ AI selected an invalid/stale target: ${decision.targetId}`
          );
          actionHistory.push({
            step,
            action: decision.action,
            targetId: decision.targetId,
            value: decision.value,
            result: `failed: ${executionError}`
          });
          console.log(
            "🔄 Skipping stale AI target and continuing with fresh DOM on next step."
          );
          continue;
        }
        const previouslyFailed = actionHistory.some(
          (entry) =>
            entry.action === decision.action &&
            entry.targetId === decision.targetId &&
            entry.result.startsWith("failed:")
        );
        if (previouslyFailed) {
          executionError =
            "Action previously failed for this target. Skipping duplicate action.";
          console.warn(
            `⚠️ Skipping previously failed action: ${decision.action} -> ${decision.targetId}`
          );
          actionHistory.push({
            step,
            action: decision.action,
            targetId: decision.targetId,
            value: decision.value,
            result: `failed: ${executionError}`
          });
          continue;
        }
        executionResult =
          await executeAction(
            page,
            decision
          );
        console.log(
          "✅ Action executed"
        );
        actionHistory.push({
          step,
          action: decision.action,
          targetId: decision.targetId,
          value: decision.value,
          result: "executed"
        });
      } catch (error) {
        executionError =
          error instanceof Error
            ? error.message
            : String(error);
        console.error(
          "❌ Action failed:"
        );
        console.error(
          executionError
        );
        actionHistory.push({
          step,
          action: decision.action,
          targetId: decision.targetId,
          value: decision.value,
          result: `failed: ${executionError}`
        });
      }
      /*
       * 8. Give UI a short moment to react
       */
      await page
        .waitForTimeout(1000)
        .catch(() => { });
      /*
       * 9. Capture resulting state
       */
      const afterUrl =
        page.url();
      const afterTitle =
        await page.title().catch(
          () => ""
        );
      let currentBodyText = "";
      try {
        currentBodyText =
          await page.locator("body")
            .innerText({
              timeout: 5_000,
            });
      } catch {
        currentBodyText = "";
      }
      /*
       * 10. Analyze behavior
       *
       * This is the AI chaos classification
       * layer.
       */
      const observation: ChaosObservation =
        await analyzeChaos({
          action:
            decision.action,
          targetId:
            decision.targetId,
          value:
            decision.value,
          reason:
            decision.reason,
          beforeUrl,
          afterUrl,
          beforeTitle,
          afterTitle,
          bodyText:
            currentBodyText,
          executionError,
          executionResult,
        });
      explorationHistory.push(observation);
      console.log(
        "\n🧠 OBSERVATION STORED"
      );
      console.log(
        JSON.stringify(observation, null, 2)
      );
      console.log(
        "\n🔎 CHAOS ANALYSIS"
      );
      console.log(
        JSON.stringify(
          observation,
          null,
          2
        )
      );
      /*
       * 11. Convert observation into report
       */
      if (
        observation.category !==
        "NONE" ||
        observation.isEdgeCase
      ) {
        const report: ChaosReport = {
          timestamp:
            new Date().toISOString(),
          title:
            observation.title ||
            "AI Detected Application Behavior",
          severity:
            observation.severity,
          category:
            observation.category,
          action:
            decision.action,
          targetId:
            decision.targetId,
          value:
            decision.value,
          reason:
            observation.reason ||
            decision.reason ||
            "AI identified unusual application behavior.",
          observedBehavior:
            observation.observedBehavior,
          expectedBehavior:
            observation.expectedBehavior,
          isEdgeCase:
            observation.isEdgeCase,
          confidence:
            observation.confidence,
          evidence:
            observation.evidence || [],
          url:
            page.url(),
          error:
            executionError,
          recommendation:
            observation.recommendation,
        };
        reports.push(report);
        console.log(
          "\n🚨 FINDING DETECTED"
        );
        console.log(
          JSON.stringify(
            report,
            null,
            2
          )
        );
      } else {
        console.log(
          "\n✅ No significant anomaly detected."
        );
      }
      /*
       * 12. Save screenshot for every step
       */
      try {
        await fs.mkdir(
          "screenshots",
          {
            recursive: true,
          }
        );
        await page.screenshot({
          path: path.join(
            "screenshots",
            `step-${step}.png`
          ),
          fullPage: true,
        });
      } catch {
        console.log(
          "⚠️ Screenshot could not be saved."
        );
      }
      /*
       * 13. If action failed, continue
       * so the analyzer can still classify it.
       */
      if (executionError) {
        console.log(
          "\n⚠️ Continuing exploration after action failure."
        );
      }
    }
    /*
     * ==================================================
     * FINAL REPORT GENERATION
     * ==================================================
     */
    console.log(
      "\n\n=================================================="
    );
    console.log(
      "📊 GENERATING FINAL CHAOS QA REPORT"
    );
    console.log(
      "=================================================="
    );
    console.log(
      `Total findings: ${reports.length}`
    );
    const generated =
      await generateChaosReports(
        reports,
        "reports",
        actionHistory,
        explorationHistory
      );
    console.log(
      "\n✅ Reports generated:"
    );
    console.log(
      `📄 JSON: ${generated.json}`
    );
    console.log(
      `📝 Markdown: ${generated.markdown}`
    );
    console.log(
      `🌐 HTML: ${generated.html}`
    );
    console.log(
      "\n=================================================="
    );
    console.log(
      "🎉 AUTONOMOUS AI CHAOS QA COMPLETED"
    );
    console.log(
      "==================================================\n"
    );
  }
);