import { defineConfig, devices } from "@playwright/test";
import dotenv from "dotenv";
dotenv.config();
export default defineConfig({
 testDir: "./tests",
 timeout: 180_000,
 expect: {
   timeout: 10_000,
 },
 fullyParallel: false,
 forbidOnly: !!process.env.CI,
 retries: process.env.CI ? 2 : 0,
 workers: 1,
 reporter: [
   ["list"],
   ["html", { outputFolder: "playwright-report", open: "never" }],
 ],
 use: {
    baseURL: "http://127.0.0.1:8080",
    headless: true,
   actionTimeout: 15_000,
   navigationTimeout: 60_000,
   screenshot: "only-on-failure",
   video: "retain-on-failure",
   trace: "retain-on-failure",
   ignoreHTTPSErrors: true,
 },
  webServer: {
    command: "http-server . -p 8080 -s",
    url: "http://127.0.0.1:8080/chaos-playground/",
    reuseExistingServer: true,
    timeout: 30_000,
  },
 projects: [
   {
     name: "chromium",
     use: {
       ...devices["Desktop Chrome"],
     },
   },
 ],
});