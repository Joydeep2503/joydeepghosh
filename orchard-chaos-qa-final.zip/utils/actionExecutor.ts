import { Page } from "@playwright/test";
type Action = {
  action: string;
  targetId?: string;
  value?: string;
  reason?: string;
};
export async function executeAction(
  page: Page,
  action: Action
): Promise<void> {
  console.log("");
  console.log("==============================================");
  console.log("🤖 AI ACTION EXECUTOR");
  console.log("==============================================");
  console.log(JSON.stringify(action, null, 2));
  switch (action.action) {
    case "click": {
      await executeElementAction(
        page,
        action,
        "click"
      );
      break;
    }
    case "doubleClick": {
      await executeElementAction(
        page,
        action,
        "doubleClick"
      );
      break;
    }
    case "fill": {
      await executeFill(page, action);
      break;
    }
    case "select": {
      await executeSelect(page, action);
      break;
    }
    case "hover": {
      await executeElementAction(
        page,
        action,
        "hover"
      );
      break;
    }
    case "scroll": {
      console.log("🖱️ AI SCROLL");
      await page.mouse.wheel(0, 700);
      await page.waitForTimeout(500);
      break;
    }
    case "wait": {
      const waitTime = Number(action.value || 1000);
      console.log(
        `⏳ AI WAIT → ${waitTime}ms`
      );
      await page.waitForTimeout(waitTime);
      break;
    }
    case "goBack": {
      console.log("⬅️ AI GO BACK");
      await page.goBack({
        waitUntil: "domcontentloaded",
        timeout: 10000,
      }).catch(() => {
        console.log(
          "⚠️ Browser could not go back."
        );
      });
      break;
    }
    case "goForward": {
      console.log("➡️ AI GO FORWARD");
      await page.goForward({
        waitUntil: "domcontentloaded",
        timeout: 10000,
      }).catch(() => {
        console.log(
          "⚠️ Browser could not go forward."
        );
      });
      break;
    }
    case "reload": {
      console.log("🔄 AI RELOAD");
      await page.reload({
        waitUntil: "domcontentloaded",
        timeout: 15000,
      });
      break;
    }
    case "none": {
      console.log(
        "ℹ️ AI selected NONE."
      );
      break;
    }
    default: {
      throw new Error(
        `Unknown AI action: ${action.action}`
      );
    }
  }
  console.log(
    "✅ AI action execution completed."
  );
}
/**
 * Executes actions that require an element.
 */
async function executeElementAction(
  page: Page,
  action: Action,
  actionType:
    | "click"
    | "doubleClick"
    | "hover"
): Promise<void> {
  if (!action.targetId) {
    throw new Error(
      `AI did not provide targetId for ${actionType} action.`
    );
  }
  console.log(
    `🎯 AI TARGET → ${action.targetId}`
  );
  const locator = page.locator(
    `[data-ai-id="${action.targetId}"]`
  );
  const count = await locator.count();
  console.log(
    `🔎 Matching elements → ${count}`
  );
  /*
   * IMPORTANT:
   *
   * If the AI selected an element that no longer exists,
   * we DO NOT immediately crash the whole test.
   *
   * This is itself useful information for the QA engine.
   */
  if (count === 0) {
    console.log(
      `⚠️ Target ${action.targetId} no longer exists.`
    );
    throw new Error(
      `AI_TARGET_NOT_FOUND:${action.targetId}`
    );
  }
  const element = locator.first();
  try {
    await element.scrollIntoViewIfNeeded({
      timeout: 3000,
    });
  } catch {
    console.log(
      "⚠️ Could not scroll element into view."
    );
  }
  try {
    await element.waitFor({
      state: "visible",
      timeout: 3000,
    });
  } catch {
    console.log(
      "⚠️ Element is not currently visible."
    );
  }
  switch (actionType) {
    case "click": {
      console.log(
        `🖱️ AI CLICK → ${action.targetId}`
      );
      await element.click({
        timeout: 5000,
      });
      break;
    }
    case "doubleClick": {
      console.log(
        `🖱️ AI DOUBLE CLICK → ${action.targetId}`
      );
      await element.dblclick({
        timeout: 5000,
      });
      break;
    }
    case "hover": {
      console.log(
        `🖱️ AI HOVER → ${action.targetId}`
      );
      await element.hover({
        timeout: 5000,
      });
      break;
    }
  }
}
/**
 * Executes AI fill actions.
 */
async function executeFill(
  page: Page,
  action: Action
): Promise<void> {
  if (!action.targetId) {
    throw new Error(
      "AI did not provide targetId for fill action."
    );
  }
  if (
    action.value === undefined ||
    action.value === null
  ) {
    throw new Error(
      "AI did not provide a value for fill action."
    );
  }
  console.log(
    `✏️ AI FILL → ${action.targetId}`
  );
  console.log(
    `📝 VALUE → ${JSON.stringify(action.value)}`
  );
  const locator = page.locator(
    `[data-ai-id="${action.targetId}"]`
  );
  const count = await locator.count();
  console.log(
    `🔎 Matching elements → ${count}`
  );
  if (count === 0) {
    throw new Error(
      `AI_TARGET_NOT_FOUND:${action.targetId}`
    );
  }
  const element = locator.first();
  const tagName = await element.evaluate(
    (el) =>
      el.tagName.toLowerCase()
  );
  const contentEditable =
    await element.getAttribute(
      "contenteditable"
    );
  const isFillable =
    tagName === "input" ||
    tagName === "textarea" ||
    contentEditable === "true";
  if (!isFillable) {
    throw new Error(
      `AI selected "${action.targetId}" for fill, but <${tagName}> is not fillable.`
    );
  }
  await element.scrollIntoViewIfNeeded({
    timeout: 3000,
  });
  await element.fill(
    String(action.value),
    {
      timeout: 5000,
    }
  );
  console.log(
    "✅ Fill completed."
  );
}
/**
 * Executes AI select actions.
 */
async function executeSelect(
  page: Page,
  action: Action
): Promise<void> {
  if (!action.targetId) {
    throw new Error(
      "AI did not provide targetId for select action."
    );
  }
  if (
    action.value === undefined ||
    action.value === null
  ) {
    throw new Error(
      "AI did not provide a value for select action."
    );
  }
  console.log(
    `🔽 AI SELECT → ${action.targetId}`
  );
  console.log(
    `📝 VALUE → ${JSON.stringify(action.value)}`
  );
  const locator = page.locator(
    `[data-ai-id="${action.targetId}"]`
  );
  const count = await locator.count();
  console.log(
    `🔎 Matching elements → ${count}`
  );
  if (count === 0) {
    throw new Error(
      `AI_TARGET_NOT_FOUND:${action.targetId}`
    );
  }
  const element = locator.first();
  const tagName = await element.evaluate(
    (el) =>
      el.tagName.toLowerCase()
  );
  if (tagName !== "select") {
    throw new Error(
      `AI selected "${action.targetId}" for select, but element is <${tagName}>.`
    );
  }
  await element.scrollIntoViewIfNeeded({
    timeout: 3000,
  });
  await element.selectOption(
    String(action.value),
    {
      timeout: 5000,
    }
  );
  console.log(
    "✅ Select completed."
  );
}
 