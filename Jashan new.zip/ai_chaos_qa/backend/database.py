"""
SQLite persistence layer for AI Chaos QA.
"""
import sqlite3
import json
import threading
from datetime import datetime, timezone

from backend.config import DB_PATH

_lock = threading.Lock()


def get_connection():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_connection()
    cur = conn.cursor()
    cur.executescript(
        """
        CREATE TABLE IF NOT EXISTS runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            target_url TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'discovering',
            plan TEXT,
            endpoints TEXT,
            started_at TEXT,
            finished_at TEXT,
            error TEXT
        );

        CREATE TABLE IF NOT EXISTS test_results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_id INTEGER NOT NULL,
            scenario TEXT NOT NULL,
            endpoint TEXT NOT NULL,
            method TEXT NOT NULL,
            test_case TEXT,
            request_payload TEXT,
            status_code INTEGER,
            response_time_ms REAL,
            response_body TEXT,
            is_anomaly INTEGER DEFAULT 0,
            anomaly_reason TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(run_id) REFERENCES runs(id)
        );

        CREATE TABLE IF NOT EXISTS reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_id INTEGER NOT NULL,
            summary TEXT,
            findings TEXT,
            recommendations TEXT,
            resilience_score REAL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(run_id) REFERENCES runs(id)
        );
        """
    )
    conn.commit()
    conn.close()


def now_iso():
    return datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Runs
# ---------------------------------------------------------------------------
def create_run(target_url):
    """Creates a run row in 'discovering' state. Scenarios/endpoints are not
    known yet - they're filled in later once discovery + AI planning finish."""
    with _lock:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO runs (target_url, status, started_at) VALUES (?, 'discovering', ?)",
            (target_url, now_iso()),
        )
        conn.commit()
        run_id = cur.lastrowid
        conn.close()
        return run_id


def update_status(run_id, status):
    with _lock:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("UPDATE runs SET status = ? WHERE id = ?", (status, run_id))
        conn.commit()
        conn.close()


def set_run_plan(run_id, plan, endpoints):
    with _lock:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            "UPDATE runs SET plan = ?, endpoints = ? WHERE id = ?",
            (json.dumps(plan), json.dumps(endpoints), run_id),
        )
        conn.commit()
        conn.close()


def finish_run(run_id, status="completed", error=None):
    with _lock:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            "UPDATE runs SET status = ?, finished_at = ?, error = ? WHERE id = ?",
            (status, now_iso(), error, run_id),
        )
        conn.commit()
        conn.close()


def get_run(run_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM runs WHERE id = ?", (run_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def list_runs(limit=50):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM runs ORDER BY id DESC LIMIT ?", (limit,))
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Test results
# ---------------------------------------------------------------------------
def add_result(run_id, scenario, endpoint, method, test_case, request_payload,
                status_code, response_time_ms, response_body, is_anomaly, anomaly_reason):
    with _lock:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            """INSERT INTO test_results
               (run_id, scenario, endpoint, method, test_case, request_payload,
                status_code, response_time_ms, response_body, is_anomaly, anomaly_reason, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (run_id, scenario, endpoint, method, test_case,
             json.dumps(request_payload) if request_payload is not None else None,
             status_code, response_time_ms,
             (response_body or "")[:2000],
             1 if is_anomaly else 0, anomaly_reason, now_iso()),
        )
        conn.commit()
        conn.close()


def get_results(run_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM test_results WHERE run_id = ? ORDER BY id ASC", (run_id,))
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Reports
# ---------------------------------------------------------------------------
def save_report(run_id, summary, findings, recommendations, resilience_score):
    with _lock:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            """INSERT INTO reports (run_id, summary, findings, recommendations, resilience_score, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (run_id, summary, json.dumps(findings), json.dumps(recommendations),
             resilience_score, now_iso()),
        )
        conn.commit()
        conn.close()


def get_report(run_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM reports WHERE run_id = ? ORDER BY id DESC LIMIT 1", (run_id,))
    row = cur.fetchone()
    conn.close()
    if not row:
        return None
    d = dict(row)
    d["findings"] = json.loads(d["findings"]) if d["findings"] else []
    d["recommendations"] = json.loads(d["recommendations"]) if d["recommendations"] else []
    return d
