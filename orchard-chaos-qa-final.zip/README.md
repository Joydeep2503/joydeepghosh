# Orchard Chaos QA

Orchard is an autonomous user-behavior exploration harness for Playwright and
TypeScript. It explores a deliberately dynamic, Apple-inspired commerce
playground, records the actions it has taken, separates **edge cases** from
unexpected **exceptions**, and produces JSON, Markdown, and an interactive
dark-mode HTML report.

## Run in VS Code

1. Extract the ZIP and open the extracted folder in VS Code.
2. Open the integrated terminal in that folder.
3. Install dependencies: `npm install`
4. Install the browser once: `npx playwright install chromium`
5. Run deterministic commerce checks: `npm test -- tests/ecommerce.spec.ts`
6. Run TypeScript validation: `npm run typecheck`
7. Run autonomous exploration:

   `MAX_STEPS=12 npm test -- tests/dom.spec.ts`

   On Windows PowerShell use:
   `$env:MAX_STEPS="12"; npm test -- tests/dom.spec.ts`

The local playground is served automatically at
`http://127.0.0.1:8080/chaos-playground/`. Use `TARGET_URL` to explore another
Playwright-compatible URL. The AI exploration requires `GROQ_API_KEY` in a
local `.env` file; never commit that file. `MODEL` optionally selects the
Groq model.

## Reports and memory

- `reports/chaos-report.html` is the interactive report. It has dark mode,
  finding-type filters, severity badges, action timeline, evidence, and
  recommendations.
- `reports/chaos-report.json` is machine-readable.
- `reports/chaos-report.md` is review-friendly.
- `reports/exploration-memory.json` persists action signatures between runs, so
  the agent skips actions it has already explored. Delete only this file when
  you intentionally want a fresh exploration campaign.

The memory is bounded by unique action signatures rather than screenshots or
credentials. A skipped action is still recorded in the timeline, making the
agent's decision visible without repeating side effects.

## Design notes

The existing action executor, DOM extractor, LLM adapter, analyzer, and report
formats remain intact. The new memory layer is additive. Stable `data-ai-id`
attributes are preferred where the application provides them, while generated
IDs preserve compatibility for arbitrary targets. Validation feedback is
treated as normal boundary behavior; browser/application failures are reported
as exceptions.