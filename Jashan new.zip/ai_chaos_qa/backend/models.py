"""
Pydantic request/response schemas for the AI Chaos QA backend API.
"""
from pydantic import BaseModel, Field


class RunAutoStartRequest(BaseModel):
    target_url: str = Field(
        ...,
        description=(
            "Any base URL or full page URL - e.g. http://localhost:9000 (a FastAPI "
            "service, discovered via its OpenAPI schema) or https://www.example.com/some-page "
            "(a plain URL with no API spec, probed generically)."
        ),
    )
    verify_ssl: bool = Field(
        default=True,
        description=(
            "Set to false to skip TLS certificate verification. Needed on networks with a "
            "TLS-inspecting corporate proxy that causes SSLCertVerificationError against "
            "otherwise-valid HTTPS targets."
        ),
    )


class RunStartResponse(BaseModel):
    run_id: int
    status: str
