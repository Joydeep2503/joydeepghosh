import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Ollama (local LLM) settings
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434/api/generate")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2")

# SQLite database file
DATA_DIR = os.path.join(BASE_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)
DB_PATH = os.getenv("CHAOS_DB_PATH", os.path.join(DATA_DIR, "chaos_qa.db"))

# Response time SLA used to flag latency anomalies (milliseconds)
DEFAULT_TIMEOUT_SLA_MS = int(os.getenv("CHAOS_SLA_MS", "2000"))

# Client-side request timeout used when probing the AUT (seconds)
PROBE_TIMEOUT_SEC = float(os.getenv("CHAOS_PROBE_TIMEOUT_SEC", "2.0"))

# --- Fault Injection & Recovery Monitoring (backend/recovery_engine.py) ---
# How often to poll the target while waiting for it to recover (seconds)
RECOVERY_POLL_INTERVAL_SEC = float(os.getenv("RECOVERY_POLL_INTERVAL_SEC", "1.0"))
# Give up and report "did not recover" after this many poll attempts
RECOVERY_MAX_ATTEMPTS = int(os.getenv("RECOVERY_MAX_ATTEMPTS", "30"))
# How many consecutive healthy (2xx) responses are required before declaring "recovered"
RECOVERY_CONSECUTIVE_HEALTHY = int(os.getenv("RECOVERY_CONSECUTIVE_HEALTHY", "2"))
# When a chaos hook is available: how many probes to take while the fault is
# deliberately held active, to document the degraded state before "fixing" it
RECOVERY_DOWN_OBSERVATION_ATTEMPTS = int(os.getenv("RECOVERY_DOWN_OBSERVATION_ATTEMPTS", "3"))
# When no chaos hook is available: how many concurrent requests to fire as the
# fault-injection mechanism (kept modest to be safe against real third-party targets)
RECOVERY_BURST_REQUESTS = int(os.getenv("RECOVERY_BURST_REQUESTS", "12"))
