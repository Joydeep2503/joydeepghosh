import { test, expect } from "@playwright/test";

test.describe("Orchard commerce contract", () => {
  test("search, filter, sort, product options, and cart", async ({ page }) => {
    await page.goto("/chaos-playground/");
    await expect(page.locator("[data-testid^='product-']")).toHaveCount(8);
    await page.locator("#searchInput").fill("phone");
    await expect(page.locator("[data-testid^='product-']")).toHaveCount(2);
    await page.locator("#categoryButton").click();
    await expect(page.locator("#categoryButton")).toContainText("Phone");
    await expect(page.locator("[data-testid^='product-']")).toHaveCount(2);
    await page.locator("[data-testid='product-phone-pro'] .add").click();
    await page.locator("#quantity").fill("0");
    await page.locator("#addToBag").click();
    await expect(page.locator("#productAlert")).toContainText("1 to 10");
    await page.locator("#quantity").fill("2");
    await page.locator("#addToBag").click();
    await page.locator("#cartButton").click();
    await expect(page.locator("#modalContent")).toContainText("Orchard Phone Pro");
  });

  test("checkout rejects missing and malformed customer data", async ({ page }) => {
    await page.goto("/chaos-playground/");
    await page.locator("[data-testid='product-phone-air'] .add").click();
    await page.locator("#addToBag").click();
    await page.locator("#cartButton").click();
    await page.locator("#checkoutButton").click();
    await page.locator("#payButton").click();
    await expect(page.locator("#checkoutError")).toContainText("required");
    await page.locator("#name").fill("QA User");
    await page.locator("#email").fill("not-an-email");
    await page.locator("#card").fill("4242424242424242");
    await page.locator("#expiry").fill("12/30 123");
    await page.locator("#payButton").click();
    await expect(page.locator("#checkoutError")).toContainText("valid email");
  });

  test("invalid and blank promo codes remain recoverable", async ({ page }) => {
    await page.goto("/chaos-playground/");
    await page.locator("[data-testid='product-buds-max'] .add").click();
    await page.locator("#addToBag").click();
    await page.locator("#cartButton").click();
    await page.locator("#applyPromo").click();
    await expect(page.locator("#promoMessage")).toContainText("Enter a promo");
    await page.locator("#promo").fill("NOPE");
    await page.locator("#applyPromo").click();
    await expect(page.locator("#promoMessage")).toContainText("isn't valid");
  });
});