import { Page } from "@playwright/test";
export async function extractPageData(page: Page) {
    const pageData = await page.evaluate(() => {
        // 1. Find interactive elements
        const elements = Array.from(
            document.querySelectorAll(
                `
                button,
                a,
                input,
                textarea,
                select,
                [role="button"],
                [role="link"]
                `
            )
        );
        // 2. Keep ONLY visible and enabled elements
        const visibleElements = elements.filter((el) => {
            const element = el as HTMLElement;
            const rect = element.getBoundingClientRect();
            const style = window.getComputedStyle(element);
            const isVisible =
                rect.width > 0 &&
                rect.height > 0 &&
                style.display !== "none" &&
                style.visibility !== "hidden" &&
                style.opacity !== "0" &&
                !element.hasAttribute("hidden");
            const isDisabled =
                (element as HTMLInputElement).disabled === true ||
                element.getAttribute("aria-disabled") === "true";
            return isVisible && !isDisabled;
        });
        // 3. Give every visible interactive element an AI ID
        return visibleElements.map((el, index) => {
            const aiId = `element-${index + 1}`;
            const element = el as HTMLElement;
            // Add the AI ID directly to the live DOM
            element.setAttribute("data-ai-id", aiId);
            const rect = element.getBoundingClientRect();
            return {
                id: aiId,
                tag: element.tagName.toLowerCase(),
                text:
                    element.innerText ||
                    element.getAttribute("aria-label") ||
                    "",
                type:
                    element.getAttribute("type") ||
                    "",
                name:
                    element.getAttribute("name") ||
                    "",
                placeholder:
                    element.getAttribute("placeholder") ||
                    "",
                value:
                    (element as HTMLInputElement).value ||
                    "",
                href:
                    element.getAttribute("href") ||
                    "",
                disabled:
                    (element as HTMLInputElement).disabled ||
                    false,
                visible:
                    rect.width > 0 &&
                    rect.height > 0,
                x: Math.round(rect.x),
                y: Math.round(rect.y),
                width: Math.round(rect.width),
                height: Math.round(rect.height)
            };
        });
    });
    // 4. Return page information + extracted elements
    return {
        title: await page.title(),
        url: page.url(),
        elements: pageData
    };
}
 