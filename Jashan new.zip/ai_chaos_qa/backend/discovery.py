"""
Endpoint Discovery
-------------------
Two discovery modes, chosen automatically per target - no manual switch needed:

1. "openapi" mode (preferred): if the target exposes a FastAPI-generated
   OpenAPI schema (GET /openapi.json), every operation is parsed dynamically
   into an endpoint config with a synthesized sample payload - no hardcoded
   endpoint list anywhere in this codebase.

2. "generic" mode (fallback): if no OpenAPI schema is found (a plain website,
   a non-FastAPI service, or any URL with no REST spec - e.g.
   https://www.geeksforgeeks.org/some-page), the target URL itself becomes a
   single GET endpoint. Only scenarios that make sense for an unstructured
   URL will apply (the AI planner restricts to failure/timeout probing in
   this mode - see ai_planner.py).

Both modes support an optional verify_ssl flag, since many corporate
networks intercept HTTPS with a proxy certificate that Python doesn't trust
by default, causing SSLCertVerificationError on otherwise-valid targets.
"""
import re
from urllib.parse import urlsplit, urlunsplit

import requests

SKIP_PATH_PREFIXES = ("/docs", "/redoc", "/openapi", "/favicon.ico")
HTTP_METHODS = ("get", "post", "put", "delete", "patch")


def _normalize_url(target_url):
    """Adds a scheme if missing (e.g. 'www.example.com' -> 'https://www.example.com')."""
    target_url = target_url.strip()
    if not re.match(r"^https?://", target_url, re.IGNORECASE):
        target_url = "https://" + target_url
    return target_url


def _split_base_and_path(target_url):
    """Splits a full URL into (base = scheme://netloc, path incl. query)."""
    parts = urlsplit(target_url)
    base = urlunsplit((parts.scheme, parts.netloc, "", "", ""))
    path = urlunsplit(("", "", parts.path or "/", parts.query, ""))
    return base, path or "/"


def _resolve_schema(schema, components, depth=0):
    if schema is None or depth > 6:
        return None
    if "$ref" in schema:
        ref_name = schema["$ref"].split("/")[-1]
        return _resolve_schema(components.get(ref_name, {}), components, depth + 1)
    if "example" in schema:
        return schema["example"]

    schema_type = schema.get("type")
    if schema_type == "object" or "properties" in schema:
        props = schema.get("properties", {})
        return {k: _resolve_schema(v, components, depth + 1) for k, v in props.items()}
    if schema_type == "array":
        item = _resolve_schema(schema.get("items", {}), components, depth + 1)
        return [item] if item is not None else []
    if schema_type == "integer":
        return 1
    if schema_type == "number":
        return 1.0
    if schema_type == "boolean":
        return True
    if schema_type == "string":
        fmt = schema.get("format")
        if fmt == "email":
            return "user@example.com"
        if fmt in ("date", "date-time"):
            return "2026-01-01"
        return "sample_text"
    return None


def _discover_via_openapi(spec_base, verify_ssl, timeout):
    """Attempts OpenAPI-based discovery against a candidate base URL (which
    may include a path prefix, e.g. https://host/api/v3). Raises on any
    failure (network, SSL, non-200, or a response that isn't a valid OpenAPI
    document) so the caller can try the next candidate / fall back."""
    spec_url = spec_base.rstrip("/") + "/openapi.json"
    resp = requests.get(spec_url, timeout=timeout, verify=verify_ssl)
    resp.raise_for_status()
    spec = resp.json()
    if "paths" not in spec:
        raise ValueError("Response did not look like an OpenAPI schema (no 'paths' key).")

    components = spec.get("components", {}).get("schemas", {})
    endpoints = []

    for path, operations in spec.get("paths", {}).items():
        if any(path.startswith(p) for p in SKIP_PATH_PREFIXES):
            continue
        for method, op in operations.items():
            if method.lower() not in HTTP_METHODS:
                continue

            sample_payload = None
            request_body = op.get("requestBody")
            if request_body:
                json_schema = (
                    request_body.get("content", {}).get("application/json", {}).get("schema")
                )
                if json_schema:
                    sample_payload = _resolve_schema(json_schema, components)

            # Fill in any path parameters (e.g. /products/{product_id} -> /products/1)
            resolved_path = re.sub(r"\{[^/]+\}", "1", path)

            endpoints.append(
                {
                    "name": op.get("summary") or op.get("operationId") or f"{method.upper()} {path}",
                    "method": method.upper(),
                    "path": resolved_path,
                    "sample_payload": sample_payload,
                }
            )

    return endpoints


def _discover_generic(target_url):
    """Fallback for targets with no OpenAPI schema: treat the given URL
    itself as the single endpoint to probe."""
    _, path = _split_base_and_path(target_url)
    return [
        {
            "name": f"GET {path}",
            "method": "GET",
            "path": path,
            "sample_payload": None,
        }
    ]


def discover_endpoints(target_url, verify_ssl=True, timeout=5):
    """Returns (endpoints, mode, effective_base_url).

    mode is "openapi" or "generic". effective_base_url is the base every
    endpoint "path" should be joined onto to form a real request URL - this
    matters because some APIs are mounted under a path prefix (e.g. Swagger
    Petstore's spec lives at https://petstore3.swagger.io/api/v3/openapi.json,
    not at the domain root), so the prefix that successfully served the spec
    has to be reused for every subsequent probe.

    Tries, in order:
      1. the exact URL you gave (as a path prefix) + /openapi.json
      2. the domain root + /openapi.json
      3. generic single-URL fallback if neither of the above is a valid
         OpenAPI document (no schema, 404, SSL/connection error, etc.)
    """
    target_url = _normalize_url(target_url)
    base_url, path = _split_base_and_path(target_url)

    candidates = []
    if path and path != "/":
        candidates.append(base_url.rstrip("/") + path.rstrip("/"))  # path-qualified, e.g. .../api/v3
    candidates.append(base_url)  # domain root

    for candidate in candidates:
        try:
            endpoints = _discover_via_openapi(candidate, verify_ssl, timeout)
            if endpoints:
                return endpoints, "openapi", candidate
        except Exception:
            continue  # try the next candidate / fall through to generic mode

    return _discover_generic(target_url), "generic", base_url
