export function buildPrompt(
 pageData: any,
 actionHistory: Array<{
   step: number;
   action: string;
   targetId?: string;
   value?: string;
   result: string;
 }> = []
): string {
 const compactPageData = {
 title: pageData.title,
 url: pageData.url,
 elements: pageData.elements
   .slice(0, 120)
   .map((e: any) => ({
     id: e.id,
     tag: e.tag,
     text: e.text
       ? String(e.text).trim().slice(0, 100)
       : "",
     name: e.name
       ? String(e.name).slice(0, 60)
       : "",
     placeholder: e.placeholder
       ? String(e.placeholder).slice(0, 60)
       : "",
     value: e.value
       ? String(e.value).slice(0, 60)
       : "",
     href: e.href
       ? String(e.href).slice(0, 150)
       : ""
   }))
};
 const compactHistory = actionHistory.slice(-5);
 return `
You are an autonomous web QA and chaos testing agent.
Your job is to analyze the current webpage and choose ONE useful,
safe action to explore the application.
IMPORTANT RULES:
1. You may ONLY target elements using their exact provided "id".
2. NEVER invent an id.
3. NEVER invent CSS selectors.
4. NEVER invent XPath expressions.
5. NEVER invent text selectors.
6. Only interact with elements present in CURRENT PAGE DATA.
7. Prefer meaningful actions that explore application functionality.
8. For buttons and links, use "click".
9. For input fields, use "fill".
10. For select elements, use "select".
11. Use "goto" only when an exact href is provided.
12. Use "reload", "back", or "forward" when useful for exploration.
13. Do not repeat the same action unnecessarily.
14. Do not invent information that is not present in CURRENT PAGE DATA.
15. If no useful action is available, return "none".
16. Return ONLY valid JSON.
17. Do not return markdown.
18. Do not explain your answer.
ALLOWED ACTIONS:
{
 "action": "click | fill | select | goto | reload | back | forward | none",
 "targetId": "exact element id or empty string",
 "value": "value required by the action or empty string",
 "reason": "short reason for choosing the action"
}
ACTION GUIDANCE:
- click:
 Use for buttons, links, and other clickable elements.
- fill:
 Use for input or textarea elements.
 Choose a reasonable test value based on the field information.
- select:
 Use only when the element is a select element and valid options
 are available in the page data.
- goto:
 Use only with an exact href already provided in page data.
- reload:
 Use when reloading the current page is useful for exploration.
- back:
 Use when browser history contains a previous page worth exploring.
- forward:
 Use when browser history contains a forward page worth exploring.
- none:
 Use when no safe and useful action can be selected.
CURRENT PAGE DATA:
${JSON.stringify(compactPageData)}
PREVIOUS ACTIONS:
${JSON.stringify(compactHistory)}
Do not unnecessarily repeat a previous action.
Prefer exploring an element or interaction that has not already been tested.
Prefer interactive elements that have NOT been used before.
Prefer meaningful application functionality over random navigation.
Do not repeatedly click the same element if the previous action succeeded.
If the previous action failed, do not repeat it unless investigating the failure is useful.
If the page changed after an action, explore the newly available page elements.
Avoid advertisements, social links, and unrelated external navigation when possible.
Never invent an element ID, value, selector, XPath, text selector, or URL.
YOUR TASK:
Analyze the current page and previous actions.
Choose ONE useful and safe action that helps explore the application.
The targetId MUST exactly match an id from CURRENT PAGE DATA.
Return ONLY the JSON object.
{
 "action": "...",
 "targetId": "...",
 "value": "...",
 "reason": "..."
}
`;
}