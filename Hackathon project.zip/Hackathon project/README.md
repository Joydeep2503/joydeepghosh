# Autonomous AI Chaos QA — Ready-to-Run Demo

This repository contains a complete local demo:
- Airbnb-style stay search and booking UI
- Guest details and payment flow
- Intentionally buggy behaviors for chaos testing
- Playwright-based autonomous explorer
- Groq GPT-OSS integration
- Deterministic boundary probes so the demo still finds bugs when the LLM is rate-limited
- JSON + HTML chaos report

## 1. Install

```bash
npm install
npx playwright install chromium
```

## 2. Configure API key

Copy `.env.example` to `.env` and put your Groq key in:

```env
GROQ_API_KEY=your_key_here
```

The default model is:

```env
GROQ_MODEL=openai/gpt-oss-120b
```

You can change it if your Groq account exposes a different GPT-OSS model.

## 3. Run the application

```bash
npm start
```

Open:

http://127.0.0.1:8080/chaos-playground/

## 4. Run autonomous chaos QA

In another terminal:

```bash
npm run qa
```

Then:

```bash
npm run report
```

Open:

```text
reports/chaos-report.html
```

## 5. Demo flow

For the mentor demo:

1. Open the StayNest application.
2. Show search/filter/listings.
3. Open a stay.
4. Continue to payment.
5. Enter an obviously invalid card value such as `123`.
6. The buggy app incorrectly reaches confirmation.
7. Run `npm run qa`.
8. Open `reports/chaos-report.html`.
9. Show the finding:
   `Invalid payment data accepted`.
10. Explain that the deterministic boundary probe guarantees a reproducible defect while the LLM adds autonomous exploration.

## Why this version is more reliable

The earlier implementation depended entirely on the LLM deciding to discover a bug. This repo separates:
- AI exploration: GPT-OSS chooses exploratory actions.
- Observation: Playwright records what happened.
- Detection: deterministic heuristics compare risky actions and resulting states.

So a Groq 429/rate-limit or an empty model response does not make the entire demo report empty.

No real payment is processed. This is a local demo application.
