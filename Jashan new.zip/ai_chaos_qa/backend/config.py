import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Ollama (local LLM) settings
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434/api/generate")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2")

# SQLite database file
DATA_DIR = os.path.join(BASE_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)
DB_PATH = os.getenv("CHAOS_DB_PATH", os.path.join(DATA_DIR, "chaos_qa.db"))

# Response time SLA used to flag latency anomalies (milliseconds)
DEFAULT_TIMEOUT_SLA_MS = int(os.getenv("CHAOS_SLA_MS", "2000"))

# Client-side request timeout used when probing the AUT (seconds)
PROBE_TIMEOUT_SEC = float(os.getenv("CHAOS_PROBE_TIMEOUT_SEC", "2.0"))
