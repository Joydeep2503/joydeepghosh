import { test } from "@playwright/test";
import { askGroq } from "../agents/llm";
test("Test LLM Connection", async () => {
 const response = await askGroq(
   "Reply with exactly: Hello Joydeep, LLM is working!"
 );
 console.log("LLM Response:");
 console.log(response);
});