import fs from "fs";
import path from "path";

const report = JSON.parse(fs.readFileSync("reports/chaos-report.json","utf8"));
const esc = s => String(s ?? "").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const cards = report.findings.map((f,i)=>`
<section class="finding">
  <div class="top"><span class="severity ${f.severity.toLowerCase()}">${esc(f.severity)}</span><span>${esc(f.category)}</span></div>
  <h2>${i+1}. ${esc(f.title)}</h2>
  <p><b>AI confidence:</b> ${Math.round((f.confidence||0)*100)}%</p>
  <p><b>Observed behavior:</b> ${esc(f.observedBehavior)}</p>
  <p><b>Expected behavior:</b> ${esc(f.expectedBehavior)}</p>
  <p><b>Evidence:</b></p><ul>${(f.evidence||[]).map(x=>`<li>${esc(x)}</li>`).join("")}</ul>
  <p><b>Recommendation:</b> ${esc(f.recommendation)}</p>
</section>`).join("");

const html = `<!doctype html><html><head><meta charset="utf-8"><title>Autonomous AI Chaos QA</title>
<style>
body{font-family:Arial;margin:0;background:#f7f7f7;color:#222}.wrap{max-width:1050px;margin:auto;padding:35px}
header{background:#171717;color:white;padding:30px;border-radius:18px;margin-bottom:20px}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.stat{background:white;border-radius:14px;padding:18px;text-align:center}.stat b{font-size:28px;display:block}
.finding{background:white;border-radius:16px;padding:25px;margin:18px 0;box-shadow:0 3px 12px #0000000d}
.top{display:flex;justify-content:space-between;color:#777}.severity{padding:5px 10px;border-radius:20px;font-weight:700}.critical{background:#fee2e2;color:#991b1b}.high{background:#ffedd5;color:#9a3412}.medium{background:#fef3c7;color:#92400e}.low{background:#e0f2fe;color:#075985}
</style></head><body><div class="wrap">
<header><h1>🤖 Autonomous AI Chaos QA</h1><p>AI-driven exploration and chaos discovery report</p><p>${esc(report.generatedAt)}</p></header>
<div class="stats">
<div class="stat"><b>${report.summary.actions}</b>AI actions / probes</div>
<div class="stat"><b>${report.summary.observations}</b>Observations</div>
<div class="stat"><b>${report.summary.chaosFindings}</b>Chaos findings</div>
<div class="stat"><b>${report.summary.edgeCases}</b>Edge cases</div>
</div>${cards || "<section class='finding'><h2>No findings</h2><p>No anomaly was detected.</p></section>"}
</div></body></html>`;

fs.writeFileSync("reports/chaos-report.html",html);
console.log("HTML: reports/chaos-report.html");
