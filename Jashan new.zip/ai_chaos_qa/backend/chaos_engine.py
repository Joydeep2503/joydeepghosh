"""
Chaos Engine
------------
Implements the four in-scope MVP capabilities from the hackathon proposal:

  1. API Failure Injection  - timeouts & HTTP 500/503 handling
  2. Partial Outage          - downstream dependency unavailability / fallback
  3. Data Inconsistency      - malformed / missing data validation
  4. Anomaly Detection       - flags anomalies as results are produced
     (AI-driven insights & recommendations are produced afterwards by
     backend/ai_analyzer.py, which reads everything this module writes to SQLite)

Each scenario function takes the target base URL + endpoint configs, exercises
the AUT, classifies each response, and writes a row to SQLite via backend.database
as soon as it's available -- this is what lets the Streamlit UI show results
"in real time" (step 2 of the proposed solution: "AI Observes Behavior").
"""
import time
import copy
import random
import string

import requests

from backend import database as db
from backend.config import DEFAULT_TIMEOUT_SLA_MS, PROBE_TIMEOUT_SEC


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _full_url(target_url, path):
    return target_url.rstrip("/") + "/" + path.lstrip("/")


def _timed_request(method, url, json_body=None, timeout=PROBE_TIMEOUT_SEC, verify_ssl=True):
    start = time.perf_counter()
    try:
        resp = requests.request(method.upper(), url, json=json_body, timeout=timeout, verify=verify_ssl)
        elapsed_ms = (time.perf_counter() - start) * 1000
        return resp.status_code, elapsed_ms, resp.text, None
    except requests.exceptions.Timeout:
        elapsed_ms = (time.perf_counter() - start) * 1000
        return None, elapsed_ms, None, "timeout"
    except requests.exceptions.SSLError as exc:
        elapsed_ms = (time.perf_counter() - start) * 1000
        return None, elapsed_ms, None, f"ssl_error: {exc}"
    except requests.exceptions.ConnectionError as exc:
        elapsed_ms = (time.perf_counter() - start) * 1000
        return None, elapsed_ms, None, f"connection_error: {exc}"
    except Exception as exc:  # noqa: BLE001
        elapsed_ms = (time.perf_counter() - start) * 1000
        return None, elapsed_ms, None, f"error: {exc}"


def _random_string(n=32):
    return "".join(random.choices(string.ascii_letters + string.digits, k=n))


def _classify(status_code, elapsed_ms, error, expect_error_ok=True):
    """Decide whether a result is an anomaly (a resilience weakness), and why."""
    if error == "timeout":
        return True, "Request timed out - no timeout guard / SLA breach on the AUT."
    if error and error.startswith("ssl_error"):
        return True, ("TLS certificate verification failed - the target's certificate isn't "
                       "trusted (common on corporate networks with TLS-inspecting proxies). "
                       "Retry the run with SSL verification disabled if this is expected.")
    if error and error.startswith("connection_error"):
        return True, "Connection failed - AUT unreachable or crashed."
    if status_code is not None and status_code >= 500:
        return True, f"Unhandled server error (HTTP {status_code}) - missing error handling."
    if status_code is not None and elapsed_ms > DEFAULT_TIMEOUT_SLA_MS:
        return True, f"Response time {elapsed_ms:.0f}ms exceeded SLA of {DEFAULT_TIMEOUT_SLA_MS}ms."
    if not expect_error_ok and status_code == 200:
        return True, "AUT returned 200 OK for invalid/malformed input instead of validating it."
    return False, None


# ---------------------------------------------------------------------------
# Scenario 1: API Failure Injection (timeouts, HTTP 500/503)
# ---------------------------------------------------------------------------
def run_api_failure_injection(run_id, target_url, endpoints, verify_ssl=True):
    for ep in endpoints:
        url = _full_url(target_url, ep["path"])

        # Test case A: baseline call under a tight client timeout, to check
        # whether the endpoint responds within an acceptable SLA.
        status, elapsed, body, error = _timed_request(
            ep.get("method", "GET"), url, ep.get("sample_payload"),
            timeout=PROBE_TIMEOUT_SEC, verify_ssl=verify_ssl,
        )
        is_anom, reason = _classify(status, elapsed, error, expect_error_ok=True)
        db.add_result(
            run_id, "api_failure_injection", ep["path"], ep.get("method", "GET"),
            "timeout_probe", ep.get("sample_payload"), status, round(elapsed, 1),
            body, is_anom, reason,
        )

        # Test case B: force a server error by hitting the endpoint with an
        # extreme / unexpected payload (large numbers, huge strings) to see
        # if the AUT crashes (500) instead of handling it gracefully.
        if ep.get("method", "GET").upper() == "POST" and ep.get("sample_payload"):
            bad_payload = {k: (10 ** 12 if isinstance(v, int) else _random_string(500))
                           for k, v in ep["sample_payload"].items()}
            status, elapsed, body, error = _timed_request(
                "POST", url, bad_payload, timeout=PROBE_TIMEOUT_SEC * 3, verify_ssl=verify_ssl,
            )
            is_anom, reason = _classify(status, elapsed, error, expect_error_ok=False)
            db.add_result(
                run_id, "api_failure_injection", ep["path"], "POST",
                "extreme_payload_5xx_probe", bad_payload, status, round(elapsed, 1),
                body, is_anom, reason,
            )

        # Test case C: repeated rapid-fire calls to check retry / consistency
        # of responses (flakiness detection).
        statuses = []
        for _ in range(3):
            status, elapsed, body, error = _timed_request(
                ep.get("method", "GET"), url, ep.get("sample_payload"),
                timeout=PROBE_TIMEOUT_SEC, verify_ssl=verify_ssl,
            )
            statuses.append(status)
        consistent = len(set(statuses)) == 1
        db.add_result(
            run_id, "api_failure_injection", ep["path"], ep.get("method", "GET"),
            "repeat_consistency_probe", ep.get("sample_payload"),
            statuses[-1], round(elapsed, 1), str(statuses),
            not consistent,
            None if consistent else f"Inconsistent responses across retries: {statuses}",
        )


# ---------------------------------------------------------------------------
# Scenario 2: Partial Outage (downstream dependency unavailability)
# ---------------------------------------------------------------------------
def run_partial_outage(run_id, target_url, endpoints, chaos_hook_path, verify_ssl=True):
    if not chaos_hook_path:
        db.add_result(
            run_id, "partial_outage", "(none)", "N/A", "skipped", None,
            None, None, "No chaos hook configured for this AUT - scenario skipped.",
            False, None,
        )
        return

    hook_url = _full_url(target_url, chaos_hook_path)

    # 1. Enable simulated outage
    status, elapsed, body, error = _timed_request("POST", hook_url, {"enable": True}, verify_ssl=verify_ssl)
    db.add_result(
        run_id, "partial_outage", chaos_hook_path, "POST", "enable_outage",
        {"enable": True}, status, round(elapsed, 1), body,
        status not in (200, 201), None if status in (200, 201) else "Failed to trigger outage simulation.",
    )

    # 2. Exercise endpoints while the dependency is "down" - a resilient AUT
    #    should degrade gracefully (e.g. 503 with a clear message, or a
    #    cached/fallback response) rather than crash or hang.
    for ep in endpoints:
        url = _full_url(target_url, ep["path"])
        status, elapsed, body, error = _timed_request(
            ep.get("method", "GET"), url, ep.get("sample_payload"),
            timeout=PROBE_TIMEOUT_SEC * 2, verify_ssl=verify_ssl,
        )
        # During an outage, a clean 503 is "graceful"; a 500/timeout/hang means
        # there is no fallback handling.
        if error == "timeout":
            is_anom, reason = True, "AUT hung instead of failing fast during downstream outage."
        elif status == 503:
            is_anom, reason = False, None  # graceful degradation - good!
        elif status is not None and status >= 500:
            is_anom, reason = True, f"AUT crashed (HTTP {status}) instead of degrading gracefully."
        else:
            is_anom, reason = False, None
        db.add_result(
            run_id, "partial_outage", ep["path"], ep.get("method", "GET"),
            "endpoint_during_outage", ep.get("sample_payload"), status,
            round(elapsed, 1), body, is_anom, reason,
        )

    # 3. Disable the simulated outage again (cleanup)
    status, elapsed, body, error = _timed_request("POST", hook_url, {"enable": False}, verify_ssl=verify_ssl)
    db.add_result(
        run_id, "partial_outage", chaos_hook_path, "POST", "disable_outage",
        {"enable": False}, status, round(elapsed, 1), body,
        status not in (200, 201), None if status in (200, 201) else "Failed to reset outage simulation.",
    )


# ---------------------------------------------------------------------------
# Scenario 3: Data Inconsistency (malformed / missing data)
# ---------------------------------------------------------------------------
def _mutate_missing_field(payload):
    if not payload:
        return None
    mutated = copy.deepcopy(payload)
    key = random.choice(list(mutated.keys()))
    del mutated[key]
    return mutated, f"missing field '{key}'"


def _mutate_wrong_type(payload):
    if not payload:
        return None
    mutated = copy.deepcopy(payload)
    key = random.choice(list(mutated.keys()))
    mutated[key] = {"unexpected": "object"} if not isinstance(mutated[key], dict) else "unexpected_string"
    return mutated, f"wrong type for '{key}'"


def _mutate_null_field(payload):
    if not payload:
        return None
    mutated = copy.deepcopy(payload)
    key = random.choice(list(mutated.keys()))
    mutated[key] = None
    return mutated, f"null value for '{key}'"


def _mutate_negative_number(payload):
    if not payload:
        return None
    mutated = copy.deepcopy(payload)
    numeric_keys = [k for k, v in mutated.items() if isinstance(v, (int, float)) and not isinstance(v, bool)]
    if not numeric_keys:
        return None
    key = random.choice(numeric_keys)
    mutated[key] = -abs(mutated[key]) - 1
    return mutated, f"negative value for '{key}'"


def _mutate_injection_string(payload):
    if not payload:
        return None
    mutated = copy.deepcopy(payload)
    str_keys = [k for k, v in mutated.items() if isinstance(v, str)]
    key = random.choice(list(mutated.keys())) if not str_keys else random.choice(str_keys)
    mutated[key] = "'; DROP TABLE orders; --"
    return mutated, f"injection-style string for '{key}'"


MUTATORS = [
    _mutate_missing_field,
    _mutate_wrong_type,
    _mutate_null_field,
    _mutate_negative_number,
    _mutate_injection_string,
]


def run_data_inconsistency(run_id, target_url, endpoints, verify_ssl=True):
    post_endpoints = [e for e in endpoints if e.get("method", "GET").upper() == "POST" and e.get("sample_payload")]
    if not post_endpoints:
        db.add_result(
            run_id, "data_inconsistency", "(none)", "N/A", "skipped", None,
            None, None, "No POST endpoints with sample payloads configured - scenario skipped.",
            False, None,
        )
        return

    for ep in post_endpoints:
        url = _full_url(target_url, ep["path"])
        for mutate in MUTATORS:
            result = mutate(ep["sample_payload"])
            if result is None:
                continue
            mutated_payload, description = result
            status, elapsed, body, error = _timed_request(
                "POST", url, mutated_payload, timeout=PROBE_TIMEOUT_SEC * 2, verify_ssl=verify_ssl,
            )

            # A well-behaved API should reject malformed input with a 4xx
            # validation error. 2xx means bad data was silently accepted;
            # 5xx means it crashed the server.
            if status is not None and 400 <= status < 500:
                is_anom, reason = False, None  # correctly validated - good!
            elif status is not None and status >= 500:
                is_anom, reason = True, f"Malformed input ({description}) crashed the server (HTTP {status})."
            elif status is not None and status < 400:
                is_anom, reason = True, f"Malformed input ({description}) was silently accepted (HTTP {status}) - no input validation."
            else:
                is_anom, reason = True, f"Malformed input ({description}) caused: {error}"

            db.add_result(
                run_id, "data_inconsistency", ep["path"], "POST", description,
                mutated_payload, status, round(elapsed, 1), body, is_anom, reason,
            )


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------
SCENARIO_FUNCS = {
    "api_failure_injection": lambda run_id, target_url, endpoints, chaos_hook_path, verify_ssl:
        run_api_failure_injection(run_id, target_url, endpoints, verify_ssl),
    "partial_outage": lambda run_id, target_url, endpoints, chaos_hook_path, verify_ssl:
        run_partial_outage(run_id, target_url, endpoints, chaos_hook_path, verify_ssl),
    "data_inconsistency": lambda run_id, target_url, endpoints, chaos_hook_path, verify_ssl:
        run_data_inconsistency(run_id, target_url, endpoints, verify_ssl),
}


def execute_run(run_id, target_url, scenarios, endpoints, chaos_hook_path, verify_ssl=True):
    """Runs the given chaos scenarios in sequence, writing results to SQLite
    as it goes. Scenario selection and endpoint discovery both happen
    upstream (backend/discovery.py + backend/ai_planner.py) - this function
    just executes whatever plan it's handed. Raises on failure; the caller
    (backend/orchestrator.py) is responsible for marking the run's final
    status so that discovery/planning/analysis phases are reflected too."""
    endpoint_dicts = [e if isinstance(e, dict) else e.dict() for e in endpoints]
    for scenario in scenarios:
        func = SCENARIO_FUNCS.get(scenario)
        if not func:
            continue
        func(run_id, target_url, endpoint_dicts, chaos_hook_path, verify_ssl)
