const fs = require("fs");
const path = require("path");

function extractJson(text) {
  const cleaned = String(text || "").replace(/```json|```/gi, "").trim();
  try { return JSON.parse(cleaned); } catch {}
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start >= 0 && end > start) {
    try { return JSON.parse(cleaned.slice(start, end + 1)); } catch {}
  }
  return null;
}

function uniqueById(targets) {
  const map = new Map();
  for (const t of targets || []) {
    if (t && t.id) map.set(t.id, t);
  }
  return [...map.values()];
}

async function callModel(messages) {
  const key = process.env.AI_API_KEY;
  if (!key) throw new Error("AI_API_KEY is missing. Copy .env.example to .env and add your API key.");

  const base = (process.env.AI_BASE_URL || "https://api.groq.com/openai/v1").replace(/\/$/, "");
  const model = process.env.AI_MODEL || "llama-3.3-70b-versatile";
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), Number(process.env.AI_TIMEOUT_MS || 30000));

  try {
    const r = await fetch(`${base}/chat/completions`, {
      method: "POST",
      headers: {"Content-Type":"application/json","Authorization":`Bearer ${key}`},
      body: JSON.stringify({
        model,
        temperature: 0.7,
        messages,
        response_format: {type:"json_object"}
      }),
      signal: controller.signal
    });
    const body = await r.text();
    if (!r.ok) throw new Error(`AI API ${r.status}: ${body.slice(0,500)}`);
    const data = JSON.parse(body);
    return data.choices?.[0]?.message?.content || "";
  } finally {
    clearTimeout(timer);
  }
}

function fallbackAction(targets, usedIds) {
  const candidates = targets.filter(t => !usedIds.has(t.id));
  const t = candidates[0] || targets[0];
  if (!t) return {action:"stop", targetId:"", value:"", reason:"No usable targets remain."};
  let action = "click";
  if (t.tag === "input") action = "fill";
  if (t.tag === "select") action = "select";
  const value = action === "fill"
    ? (t.type === "date" ? "2026-12-19" : t.type === "number" ? "0" : "123")
    : "";
  return {action, targetId:t.id, value, reason:"Explore an available target and look for unexpected validation or state behavior."};
}

async function askNextAction(context, targets, usedIds) {
  const allowed = uniqueById(targets).slice(0, 80);
  const prompt = {
    task: "Explore this application for chaos/edge-case QA. Choose ONE action using ONLY targetId values from the target inventory.",
    rules: [
      "Do not invent target IDs.",
      "Prefer an unvisited target.",
      "Probe validation boundaries and unusual but safe values.",
      "Do not submit destructive or external actions.",
      "Return JSON only."
    ],
    schema: {action:"click|fill|press|select|stop", targetId:"exact inventory id", value:"string", reason:"string"},
    state: context,
    targets: allowed,
    alreadyUsed: [...usedIds]
  };

  try {
    const text = await callModel([
      {role:"system", content:"You are an autonomous web QA agent. Follow the JSON schema exactly."},
      {role:"user", content:JSON.stringify(prompt)}
    ]);
    const parsed = extractJson(text);
    if (!parsed || !["click","fill","press","select","stop"].includes(parsed.action)) {
      return fallbackAction(allowed, usedIds);
    }
    const target = allowed.find(t => t.id === parsed.targetId);
    if (parsed.action !== "stop" && !target) return fallbackAction(allowed, usedIds);
    return parsed;
  } catch (e) {
    console.log(`⚠️ AI decision unavailable: ${e.message}`);
    return fallbackAction(allowed, usedIds);
  }
}

async function analyzeObservation(data) {
  const prompt = {
    task: "Analyze a web QA observation. Return a finding only when there is evidence of unexpected behavior, otherwise return null.",
    requiredFields: ["title","category","severity","confidence","observedBehavior","expectedBehavior","evidence","recommendation"],
    observation: data
  };

  try {
    const text = await callModel([
      {role:"system", content:"You are a senior QA analyst. Return JSON. Be conservative: do not call a normal state a bug."},
      {role:"user", content:JSON.stringify(prompt)}
    ]);
    const parsed = extractJson(text);
    if (!parsed || parsed.finding === null || parsed.issue === false) return null;
    return {
      title: parsed.title || parsed.finding || "Potential application behavior detected",
      category: parsed.category || "CHAOS",
      severity: parsed.severity || "MEDIUM",
      confidence: Number(parsed.confidence) || 75,
      observedBehavior: parsed.observedBehavior || parsed.observed || "",
      expectedBehavior: parsed.expectedBehavior || parsed.expected || "",
      evidence: parsed.evidence || "",
      recommendation: parsed.recommendation || ""
    };
  } catch (e) {
    console.log(`⚠️ Observation analysis failed: ${e.message}`);
    return null;
  }
}

async function compareWithBaseline(data) {
  const prompt = {
    task: "Compare the playground observation with the baseline observation. Identify a meaningful behavioral difference and explain whether it looks like a defect.",
    observation: data
  };
  try {
    const text = await callModel([
      {role:"system", content:"You are a QA comparison analyst. Return JSON with difference, severity, confidence, expected, observed, recommendation."},
      {role:"user", content:JSON.stringify(prompt)}
    ]);
    return extractJson(text) || {
      difference: "No reliable AI comparison was produced.",
      severity: "INFO",
      confidence: 0,
      expected: "",
      observed: "",
      recommendation: ""
    };
  } catch {
    return {
      difference: "Baseline comparison unavailable for this observation.",
      severity: "INFO",
      confidence: 0,
      expected: "",
      observed: "",
      recommendation: ""
    };
  }
}

module.exports = { askNextAction, analyzeObservation, compareWithBaseline };
