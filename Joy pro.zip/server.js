const http = require("http");
const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "chaos-playground");
const port = Number(process.env.PORT || 8080);

function safeFile(urlPath) {
  const clean = decodeURIComponent(urlPath.split("?")[0]).replace(/^\/+/, "");
  const full = path.normalize(path.join(root, clean));
  if (!full.startsWith(root)) return null;
  return full;
}

const server = http.createServer((req, res) => {
  let p = req.url || "/";
  if (p.endsWith("/")) p += "index.html";
  const file = safeFile(p.replace(/^\/chaos-playground/, ""));
  if (!file || !fs.existsSync(file)) {
    res.writeHead(404, {"Content-Type": "text/plain"});
    return res.end("Not found");
  }
  const ext = path.extname(file);
  const type = ext === ".html" ? "text/html" : ext === ".js" ? "text/javascript" : "text/plain";
  res.writeHead(200, {"Content-Type": type});
  res.end(fs.readFileSync(file));
});

server.listen(port, "127.0.0.1", () => {
  console.log(`Demo server running at http://127.0.0.1:${port}`);
});
