const http = require("http");
const fs = require("fs");
const path = require("path");

const ROOT = __dirname;
const port = Number(process.env.PORT || 8080);

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8"
};

function resolveFile(urlPath) {
  let clean = decodeURIComponent((urlPath || "/").split("?")[0]);
  if (!clean.startsWith("/")) clean = "/" + clean;

  // Only these two demo applications are exposed by the local server.
  const allowed = ["/chaos-playground/", "/normal-playground/"];
  const prefix = allowed.find(p => clean.startsWith(p));
  if (!prefix) return null;

  let relative = clean.slice(prefix.length);
  if (!relative || relative.endsWith("/")) relative += "index.html";

  const root = path.join(ROOT, prefix.slice(1));
  const file = path.normalize(path.join(root, relative));

  if (!file.startsWith(root + path.sep) && file !== root) return null;
  return file;
}

const server = http.createServer((req, res) => {
  try {
    const file = resolveFile(req.url);

    if (!file || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
      res.writeHead(404, {"Content-Type": "text/plain; charset=utf-8"});
      return res.end("Not found");
    }

    const ext = path.extname(file).toLowerCase();
    res.writeHead(200, {
      "Content-Type": MIME[ext] || "application/octet-stream",
      "Cache-Control": "no-store"
    });
    return res.end(fs.readFileSync(file));
  } catch (error) {
    res.writeHead(500, {"Content-Type": "text/plain; charset=utf-8"});
    return res.end(`Server error: ${error.message}`);
  }
});

server.listen(port, "127.0.0.1", () => {
  console.log(`Demo server running at http://127.0.0.1:${port}`);
  console.log(`Chaos:    http://127.0.0.1:${port}/chaos-playground/`);
  console.log(`Baseline: http://127.0.0.1:${port}/normal-playground/`);
});
