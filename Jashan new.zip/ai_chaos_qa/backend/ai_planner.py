"""
AI Planner
----------
This is what makes scenario selection autonomous: instead of a human
checking boxes, the discovered endpoints are handed to the local Ollama
model, which decides:
  1. which of the 3 available chaos scenarios are actually relevant to this
     API (e.g. skip data-inconsistency if there are no endpoints with a
     request body),
  2. whether any discovered endpoint looks like a "chaos hook" that can be
     used to simulate a partial outage,
  3. a short rationale for its choices (shown in the UI for transparency).

Falls back to a transparent rule-based plan if Ollama is unreachable, so the
agent still runs end-to-end without the LLM.
"""
import json
import re

import requests

from backend.config import OLLAMA_URL, OLLAMA_MODEL

ALLOWED_SCENARIOS = ["api_failure_injection", "partial_outage", "data_inconsistency"]
HOOK_KEYWORDS = ["chaos", "outage", "toggle", "fault", "simulate", "inject"]


def _extract_json(text):
    text = text.strip()
    text = re.sub(r"^```(json)?", "", text).strip()
    text = re.sub(r"```$", "", text).strip()
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if match:
        text = match.group(0)
    return json.loads(text)


def _heuristic_plan(endpoints):
    """Transparent, rule-based fallback used only if Ollama can't be reached."""
    scenarios = ["api_failure_injection"]

    has_post_body = any(e["method"] in ("POST", "PUT", "PATCH") and e["sample_payload"] for e in endpoints)
    if has_post_body:
        scenarios.append("data_inconsistency")

    hook = next(
        (e["path"] for e in endpoints
         if e["method"] == "POST" and any(k in e["path"].lower() for k in HOOK_KEYWORDS)),
        None,
    )
    if hook:
        scenarios.append("partial_outage")

    rationale = (
        "Rule-based plan (Ollama unavailable): always run API failure injection; "
        + ("include data-inconsistency because POST/PUT endpoints with a request body were found; "
           if has_post_body else "skip data-inconsistency - no endpoints with a request body found; ")
        + (f"include partial-outage using detected hook '{hook}'."
           if hook else "skip partial-outage - no chaos hook endpoint discovered.")
    )
    return {"scenarios": scenarios, "chaos_hook_path": hook, "rationale": rationale}


def plan_scenarios(target_url, endpoints, discovery_mode="openapi"):
    if discovery_mode == "generic":
        # No OpenAPI schema was found - this is a plain URL, not a structured
        # REST API. Only failure/timeout probing makes sense here; data
        # mutation and outage-hook scenarios both require API structure this
        # target doesn't expose. This is a deterministic rule, not an LLM
        # call, since it's true regardless of what the target happens to be.
        return {
            "scenarios": ["api_failure_injection"],
            "chaos_hook_path": None,
            "rationale": (
                "No OpenAPI schema was found at this target, so it's being treated as a "
                "generic URL rather than a structured REST API. Only failure/timeout "
                "probing applies - data-inconsistency and partial-outage both require "
                "request-body schemas or a chaos-hook endpoint that a plain URL doesn't have."
            ),
            "source": "rule",
        }

    endpoint_summary = [
        {"method": e["method"], "path": e["path"], "has_request_body": bool(e["sample_payload"])}
        for e in endpoints
    ]

    prompt = f"""You are an AI QA engineer planning an autonomous chaos-resilience test run
against a REST API. You were given the API's discovered endpoints (from its OpenAPI schema).

DISCOVERED ENDPOINTS:
{json.dumps(endpoint_summary, indent=2)}

AVAILABLE CHAOS SCENARIOS (choose only the ones that make sense for this specific API):
- "api_failure_injection": probes response times and induces HTTP 500/503 via extreme payloads.
   Relevant for almost any API.
- "data_inconsistency": mutates POST/PUT/PATCH request bodies (missing fields, wrong types, nulls,
   negative numbers, injection-style strings) to check input validation.
   Only relevant if endpoints with a request body exist.
- "partial_outage": simulates a downstream dependency outage by toggling a "chaos hook" endpoint.
   Only relevant if one of the discovered endpoints looks like a fault-injection toggle
   (e.g. its path contains words like chaos, outage, toggle, fault, simulate, inject).

Respond with ONLY a valid JSON object (no markdown fences, no extra commentary) with exactly these keys:
- "scenarios": array of scenario names (from the list above) that should run.
- "chaos_hook_path": the exact "path" of the endpoint to use to trigger a partial outage, or null if none exists.
- "rationale": 1-2 sentences explaining your choices.

JSON:"""

    try:
        resp = requests.post(
            OLLAMA_URL, json={"model": OLLAMA_MODEL, "prompt": prompt, "stream": False}, timeout=60
        )
        resp.raise_for_status()
        raw = resp.json().get("response", "")
        plan = _extract_json(raw)

        scenarios = [s for s in plan.get("scenarios", []) if s in ALLOWED_SCENARIOS]
        if not scenarios:
            raise ValueError("Model returned no valid scenarios")

        hook = plan.get("chaos_hook_path")
        valid_paths = {e["path"] for e in endpoints}
        if hook not in valid_paths:
            hook = None

        return {
            "scenarios": scenarios,
            "chaos_hook_path": hook,
            "rationale": plan.get("rationale", "").strip() or "AI selected these scenarios based on the discovered endpoints.",
            "source": "ai",
        }
    except Exception:
        plan = _heuristic_plan(endpoints)
        plan["source"] = "fallback"
        return plan
