"""
Recovery Engine
-----------------
Implements "inject a fault into the API, then retry until it recovers" -
against ANY discovered endpoint: the OpenAPI-backed demo AUT, a real
third-party API, or a plain URL with no API spec at all (generic mode).

Two universal fault-injection strategies are used, so this works even
without any cooperation from the target application:

  - "chaos_hook_toggle": if the AI planner found a chaos-hook endpoint
    (see ai_planner.py), it's toggled ON, held for a few probes so the
    degraded state is actually observed, then toggled OFF - that moment
    becomes the "fault cleared" anchor recovery time is measured from.
  - "concurrent_load_burst": otherwise, a burst of concurrent requests is
    fired at the endpoint to try to induce errors/latency spikes. The
    moment the burst finishes is the "fault cleared" anchor.

Every single probe - baseline, during-fault, and recovery polling - is
written to SQLite immediately via backend.database, so the frontend can
render a live timeline while this is still running.
"""
import time
import threading

import requests

from backend import database as db
from backend.config import (
    PROBE_TIMEOUT_SEC,
    RECOVERY_POLL_INTERVAL_SEC,
    RECOVERY_MAX_ATTEMPTS,
    RECOVERY_CONSECUTIVE_HEALTHY,
    RECOVERY_DOWN_OBSERVATION_ATTEMPTS,
    RECOVERY_BURST_REQUESTS,
)


def _full_url(base_url, path):
    return base_url.rstrip("/") + "/" + path.lstrip("/")


def _probe(method, url, payload, verify_ssl):
    start = time.perf_counter()
    try:
        resp = requests.request(method.upper(), url, json=payload, timeout=PROBE_TIMEOUT_SEC, verify=verify_ssl)
        return resp.status_code, (time.perf_counter() - start) * 1000, None
    except requests.exceptions.Timeout:
        return None, (time.perf_counter() - start) * 1000, "timeout"
    except requests.exceptions.SSLError as exc:
        return None, (time.perf_counter() - start) * 1000, f"ssl_error: {exc}"
    except requests.exceptions.ConnectionError as exc:
        return None, (time.perf_counter() - start) * 1000, f"connection_error: {exc}"
    except Exception as exc:  # noqa: BLE001
        return None, (time.perf_counter() - start) * 1000, f"error: {exc}"


def _is_healthy(status, error):
    return error is None and status is not None and 200 <= status < 300


def _pick_target_endpoint(endpoints, chaos_hook_path):
    """Recovery monitoring polls one endpoint repeatedly, so it must be safe
    to call over and over - GET only, and never the chaos hook itself."""
    for e in endpoints:
        if e.get("method", "GET").upper() == "GET" and e["path"] != chaos_hook_path:
            return e
    return None


def _record(run_id, endpoint, fault_type, phase, attempt, elapsed_ms, status, latency_ms, healthy, note=None):
    db.add_recovery_event(
        run_id, endpoint, fault_type, phase, attempt,
        round(elapsed_ms, 1) if elapsed_ms is not None else None,
        status,
        round(latency_ms, 1) if latency_ms is not None else None,
        healthy, note,
    )


def _inject_via_hook(run_id, base_url, target_ep, chaos_hook_path, verify_ssl):
    """Enables the chaos hook, observes the degraded state for a few probes,
    then disables it. Returns the perf_counter() timestamp the fault was
    cleared at - recovery time is measured from this anchor."""
    url = _full_url(base_url, target_ep["path"])
    hook_url = _full_url(base_url, chaos_hook_path)
    method = target_ep.get("method", "GET")
    payload = target_ep.get("sample_payload")

    requests.post(hook_url, json={"enable": True}, timeout=PROBE_TIMEOUT_SEC, verify=verify_ssl)

    for attempt in range(1, RECOVERY_DOWN_OBSERVATION_ATTEMPTS + 1):
        status, latency, error = _probe(method, url, payload, verify_ssl)
        _record(run_id, target_ep["path"], "chaos_hook_toggle", "fault_active", attempt,
                None, status, latency, _is_healthy(status, error), note=error)
        time.sleep(RECOVERY_POLL_INTERVAL_SEC)

    requests.post(hook_url, json={"enable": False}, timeout=PROBE_TIMEOUT_SEC, verify=verify_ssl)
    return time.perf_counter()


def _inject_via_burst(target_ep, base_url, verify_ssl):
    """Fires a burst of concurrent requests at the endpoint to try to induce
    errors/latency spikes. Returns the perf_counter() timestamp the burst
    finished at - recovery time is measured from this anchor."""
    url = _full_url(base_url, target_ep["path"])
    method = target_ep.get("method", "GET")
    payload = target_ep.get("sample_payload")

    def _hit():
        try:
            requests.request(method, url, json=payload, timeout=PROBE_TIMEOUT_SEC, verify=verify_ssl)
        except Exception:
            pass

    threads = [threading.Thread(target=_hit) for _ in range(RECOVERY_BURST_REQUESTS)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=PROBE_TIMEOUT_SEC * 2)
    return time.perf_counter()


def monitor_recovery(run_id, base_url, target_ep, chaos_hook_path, verify_ssl=True):
    url = _full_url(base_url, target_ep["path"])
    method = target_ep.get("method", "GET")
    payload = target_ep.get("sample_payload")

    # 1. Baseline (pre-fault) check
    base_status, base_latency, base_error = _probe(method, url, payload, verify_ssl)
    _record(run_id, target_ep["path"], "-", "baseline", 0, 0,
            base_status, base_latency, _is_healthy(base_status, base_error))

    # 2. Inject the fault
    if chaos_hook_path:
        fault_type = "chaos_hook_toggle"
        fault_cleared_at = _inject_via_hook(run_id, base_url, target_ep, chaos_hook_path, verify_ssl)
    else:
        fault_type = "concurrent_load_burst"
        fault_cleared_at = _inject_via_burst(target_ep, base_url, verify_ssl)

    # 3. Retry until recovered, or the attempt budget runs out - live polling
    consecutive_healthy = 0
    recovered = False
    recovery_time_ms = None
    attempts = []
    attempt = 0
    for attempt in range(1, RECOVERY_MAX_ATTEMPTS + 1):
        status, latency, error = _probe(method, url, payload, verify_ssl)
        elapsed_ms = (time.perf_counter() - fault_cleared_at) * 1000
        healthy = _is_healthy(status, error)
        _record(run_id, target_ep["path"], fault_type, "recovering", attempt, elapsed_ms,
                status, latency, healthy, note=error)
        attempts.append({
            "attempt": attempt, "elapsed_ms": round(elapsed_ms, 1),
            "status": status, "latency_ms": round(latency, 1), "error": error,
        })

        if healthy:
            consecutive_healthy += 1
            if consecutive_healthy >= RECOVERY_CONSECUTIVE_HEALTHY:
                recovered = True
                recovery_time_ms = elapsed_ms
                break
        else:
            consecutive_healthy = 0

        time.sleep(RECOVERY_POLL_INTERVAL_SEC)

    outcome = "recovered" if recovered else "did_not_recover"
    return {
        "endpoint": target_ep["path"],
        "fault_type": fault_type,
        "outcome": outcome,
        "recovery_time_ms": recovery_time_ms,
        "total_attempts": attempt,
        "attempts": attempts,
        "baseline": {"status": base_status, "latency_ms": round(base_latency, 1)},
    }


def run_recovery_scenario(run_id, base_url, endpoints, chaos_hook_path, verify_ssl=True):
    """Entry point used by the orchestrator. Picks a target endpoint and runs
    the full inject -> retry-until-recovered loop against it. Returns None
    (and logs a skip event) if no GET endpoint is available to poll safely."""
    target_ep = _pick_target_endpoint(endpoints, chaos_hook_path)
    if not target_ep:
        _record(run_id, "(none)", "-", "skipped", 0, None, None, None, False,
                note="No GET endpoint available to safely poll repeatedly - recovery monitoring skipped.")
        return None
    return monitor_recovery(run_id, base_url, target_ep, chaos_hook_path, verify_ssl)
