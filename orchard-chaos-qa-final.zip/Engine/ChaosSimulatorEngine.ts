import { Page } from "@playwright/test";
export type ChaosAction =
 | "scroll"
 | "hover"
 | "click"
 | "doubleClick"
 | "randomClick"
 | "randomInput"
 | "fill"
 | "refresh";
export async function executeAction(
 page: Page,
 decision: {
   action: string;
   targetId?: string;
   value?: string;
 }
): Promise<void> {
  const { action, targetId, value } = decision;
  console.log(`🤖 AI TARGET: ${targetId ?? "none"}`);
  console.log(`📝 AI VALUE: ${value ?? "none"}`);
  console.log(`\n🔥 CHAOS ACTION = ${action}`);
  switch (action) {
    case "scroll": {
      console.log("🔥 Performing SCROLL");
      await page.mouse.wheel(0, 1000);
      await page.waitForTimeout(1000);
      console.log("✅ Scroll completed");
      break;
    }
    case "hover": {
      console.log("🔥 Performing HOVER");
      const elements = page.locator(
        "a, button, input, [role='button'], img"
      );
      const count = await elements.count();
      console.log(`Found ${count} elements`);
      if (count > 0) {
        const index = Math.floor(
          Math.random() * count
        );
        console.log(`Hovering element ${index}`);
        await elements
          .nth(index)
          .hover({ timeout: 5000 })
          .catch(() => {});
      }
      await page.waitForTimeout(1000);
      console.log("✅ Hover completed");
      break;
    }
    case "doubleClick": {
      console.log("🔥 Performing DOUBLE CLICK");
      const elements = page.locator(
        "a, button, [role='button']"
      );
      const count = await elements.count();
      console.log(`Found ${count} clickable elements`);
      if (count > 0) {
        const index = Math.floor(
          Math.random() * count
        );
        console.log(`Double clicking element ${index}`);
        await elements
          .nth(index)
          .dblclick({ timeout: 5000 })
          .catch(() => {});
      }
      await page.waitForTimeout(1000);
      console.log("✅ Double click completed");
      break;
    }
    case "click": {
      console.log(`🤖 AI CLICK → ${targetId}`);
      if (!targetId) {
        throw new Error("AI selected click but no targetId was provided");
      }
      const target = page.locator(`#${targetId}`);
      await target.waitFor({
        state: "visible",
        timeout: 5000
      });
      await target.click();
      console.log(`✅ AI target clicked: ${targetId}`);
      break;
    }
    case "randomClick": {
      console.log("🔥 Performing RANDOM CLICK");
      const elements = page.locator(
        "a, button, [role='button']"
      );
      const count = await elements.count();
      console.log(`Found ${count} clickable elements`);
      if (count > 0) {
        const index = Math.floor(
          Math.random() * count
        );
        console.log(`Clicking element ${index}`);
        await elements
          .nth(index)
          .click({ timeout: 5000 })
          .catch(() => {});
      }
      await page.waitForTimeout(1000);
      console.log("✅ Random click completed");
      break;
    }
    case "randomInput": {
      console.log("🔥 Performing RANDOM INPUT");
      const inputs = page.locator(
        "input:not([type='hidden']):not([type='submit']), textarea"
      );
      const count = await inputs.count();
      console.log(`Found ${count} input fields`);
      if (count > 0) {
        const index = Math.floor(
          Math.random() * count
        );
        const values = [
          "ChaosTest",
          "123456",
          "test@test.com",
          "INVALID",
          "!!!!",
          "     "
        ];
        const value =
          values[
            Math.floor(
              Math.random() * values.length
            )
          ];
        console.log(
          `Entering "${value}" into input ${index}`
        );
        await inputs
          .nth(index)
          .fill(value, { timeout: 5000 })
          .catch(() => {});
      }
      await page.waitForTimeout(1000);
      console.log("✅ Random input completed");
      break;
    }
    case "fill": {
      console.log(`🤖 AI FILL → ${targetId} = ${value}`);
      if (!targetId) {
        throw new Error("AI selected fill but no targetId was provided");
      }
      const target = page.locator(`#${targetId}`);
      await target.waitFor({
        state: "visible",
        timeout: 5000
      });
      await target.fill(value ?? "ChaosTest");
      console.log(`✅ AI target filled: ${targetId}`);
      break;
    }
    case "refresh": {
      console.log("🔥 Performing REFRESH");
      await page.reload({
        waitUntil: "domcontentloaded"
      });
      await page.waitForTimeout(1000);
      console.log("✅ Refresh completed");
      break;
    }
  }
  console.log("🔥 CHAOS ACTION FINISHED\n");
}
 