import { test, expect } from "@playwright/test";
import { askGroq } from "../agents/llm";
test("LLM AI Connection", async () => {
 const response = await askGroq(
   "Respond with exactly this sentence: LLM connection is working."
 );
 console.log("\n========== LLM TEST ==========");
 console.log(response);
 console.log("================================\n");
 expect(response).toBeTruthy();
});