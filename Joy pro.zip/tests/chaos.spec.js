const { test } = require("@playwright/test");
const fs = require("fs");
const path = require("path");
require("dotenv").config();
const { askNextAction, analyzeObservation, compareWithBaseline } = require("../agents/ai");

const APP_URL = process.env.APP_URL || "http://127.0.0.1:8080/chaos-playground/";
const BASELINE_URL = process.env.BASELINE_URL || "http://127.0.0.1:8080/normal-playground/";
const MAX_ACTIONS = Number(process.env.MAX_ACTIONS || 10);
const ACTION_DELAY_MS = Number(process.env.ACTION_DELAY_MS || 900);
const REPORT_DIR = path.resolve("reports");

function ensureReports() {
  fs.mkdirSync(REPORT_DIR, {recursive:true});
}

async function describeTargets(page) {
  return await page.locator("button,input,select,textarea,[role='button'],a").evaluateAll(els =>
    els.map((e,i) => {
      if (!e.id) e.id = `ai-target-${i+1}`;
      return {
        id: e.id,
        tag: e.tagName.toLowerCase(),
        type: e.getAttribute("type") || "",
        text: (e.innerText || e.value || e.getAttribute("aria-label") || "").trim().slice(0,120),
        aria: e.getAttribute("aria-label") || "",
        placeholder: e.getAttribute("placeholder") || "",
        testid: e.getAttribute("data-testid") || "",
        disabled: !!e.disabled,
        visible: !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length)
      };
    }).filter(x => x.visible && !x.disabled)
  );
}

async function snapshot(page) {
  return (await page.locator("body").innerText().catch(()=>"")).slice(0,12000);
}

function valueFor(action, target) {
  if (action.action === "fill") {
    if (target.type === "date" || target.id.includes("date")) return action.value || "2026-12-19";
    if (target.type === "number" || target.id.includes("guest")) return action.value || "0";
    return action.value || "123";
  }
  if (action.action === "press") return action.value || "Enter";
  return action.value || "";
}

async function execute(page, action, targets) {
  if (!action || action.action === "stop") return false;
  const target = targets.find(t => t.id === action.targetId);
  if (!target) {
    console.log(`⚠️ ACTION skipped: target ${action.targetId} was not in the current inventory.`);
    return false;
  }

  const locator = page.locator(`#${CSS.escape(target.id)}`).first();
  try {
    console.log(`▶️ Executing ${action.action} → ${target.id}`);
    if (action.action === "click") await locator.click({timeout:Number(process.env.PLAYWRIGHT_TIMEOUT_MS || 8000)});
    else if (action.action === "fill" && ["input","textarea"].includes(target.tag)) await locator.fill(valueFor(action,target));
    else if (action.action === "press") await locator.press(valueFor(action,target));
    else if (action.action === "select" && target.tag === "select") await locator.selectOption(action.value);
    else if (action.action === "fill") return false;
    else return false;
    console.log(`✅ ${action.action.toUpperCase()} executed: ${target.id}`);
    return true;
  } catch (e) {
    console.log(`⚠️ ${action.action.toUpperCase()} failed: ${target.id}`);
    console.log(`   ${e.message.split("\n")[0]}`);
    console.log("⚠️ Action could not be executed; continuing exploration.");
    return false;
  }
}

function normalizeFinding(f, extra) {
  return {
    title: f.title || "Potential application behavior detected",
    category: f.category || "CHAOS",
    severity: f.severity || "MEDIUM",
    confidence: Number(f.confidence) || 75,
    observedBehavior: f.observedBehavior || "Unexpected behavior was observed.",
    expectedBehavior: f.expectedBehavior || "The application should follow the baseline/expected validation behavior.",
    evidence: f.evidence || extra.after.slice(-2000),
    recommendation: f.recommendation || "Validate the affected business rule and add regression coverage.",
    action: extra.action,
    baseline: extra.baseline || null
  };
}

test("Autonomous AI Chaos QA", async ({ page }) => {
  ensureReports();
  const observations = [];
  const findings = [];
  const decisions = [];
  const started = new Date().toISOString();

  console.log("\n=================================================");
  console.log("🤖 AUTONOMOUS AI CHAOS QA");
  console.log("=================================================\n");

  await page.goto(APP_URL);
  await page.waitForLoadState("domcontentloaded");

  // Capture a baseline snapshot of the normal site before chaos exploration.
  const baselinePage = await page.context().newPage();
  await baselinePage.goto(BASELINE_URL);
  await baselinePage.waitForLoadState("domcontentloaded");

  const baselineSnapshot = await snapshot(baselinePage);
  await baselinePage.close();

  const usedIds = new Set();

  for (let step = 1; step <= MAX_ACTIONS; step++) {
    console.log(`\n================ STEP ${step} ================`);
    const targets = await describeTargets(page);
    console.log(`🔎 Available targets: ${targets.length}`);

    const before = await snapshot(page);
    const state = {
      url: page.url(),
      step,
      before: before.slice(-5000)
    };

    console.log("💬 Asking AI for next exploration action...");
    const action = await askNextAction(state, targets, usedIds);
    decisions.push({step, action, timestamp:new Date().toISOString()});

    console.log("\n🎯 AI DECISION");
    console.log(`Action : ${action.action}`);
    console.log(`Target : ${action.targetId || "N/A"}`);
    console.log(`Value  : ${action.value || "N/A"}`);
    console.log(`Reason : ${action.reason || "N/A"}`);

    if (!action || action.action === "stop") {
      console.log("🛑 AI selected STOP.");
      break;
    }

    usedIds.add(action.targetId);
    const urlBefore = page.url();
    const executed = await execute(page, action, targets);

    await page.waitForTimeout(ACTION_DELAY_MS);

    const after = await snapshot(page);
    const urlAfter = page.url();

    const observation = {
      step,
      action,
      executed,
      before,
      after,
      urlBefore,
      urlAfter,
      timestamp: new Date().toISOString()
    };
    observations.push(observation);

    console.log("🔬 Analyzing application behavior...");
    const rawFinding = await analyzeObservation(observation);
    if (rawFinding) {
      const comparison = await compareWithBaseline({
        action,
        playground: {before, after, urlBefore, urlAfter},
        baseline: {snapshot: baselineSnapshot, url: BASELINE_URL}
      });
      findings.push(normalizeFinding(rawFinding, {
        action, after, baseline: comparison
      }));
      console.log(`💐 Finding detected: ${rawFinding.title}`);
    } else {
      console.log("✅ No obvious issue detected.");
    }

    await page.screenshot({
      path: path.join(REPORT_DIR, `step-${String(step).padStart(2,"0")}.png`),
      fullPage: true
    }).catch(()=>{});
  }

  const unique = [];
  const seen = new Set();
  for (const f of findings) {
    const key = `${f.title}|${f.category}|${f.severity}`.toLowerCase();
    if (!seen.has(key)) { seen.add(key); unique.push(f); }
  }

  const report = {
    generatedAt: new Date().toISOString(),
    startedAt: started,
    application: APP_URL,
    baseline: BASELINE_URL,
    summary: {
      actions: observations.length,
      observations: observations.length,
      chaosFindings: unique.length,
      failedActions: observations.filter(o => !o.executed).length,
      passedActions: observations.filter(o => o.executed).length
    },
    decisions,
    observations,
    findings: unique
  };

  fs.writeFileSync(path.join(REPORT_DIR, "chaos-report.json"), JSON.stringify(report,null,2));
  fs.writeFileSync(path.join(REPORT_DIR, "chaos-report.md"), buildMarkdown(report));
  fs.writeFileSync(path.join(REPORT_DIR, "chaos-report.html"), buildHtml(report));

  console.log("\n=================================================");
  console.log("🎉 AUTONOMOUS AI CHAOS QA COMPLETED");
  console.log(`Total actions: ${report.summary.actions}`);
  console.log(`Total findings: ${report.summary.chaosFindings}`);
  console.log(`Failed actions handled: ${report.summary.failedActions}`);
  console.log("HTML: reports/chaos-report.html");
  console.log("JSON: reports/chaos-report.json");
  console.log("Markdown: reports/chaos-report.md");
  console.log("=================================================\n");
});

function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

function buildMarkdown(r) {
  let md = `# Autonomous AI Chaos QA Report\n\n`;
  md += `Generated: ${r.generatedAt}\n\n`;
  md += `## Summary\n\n| Metric | Value |\n|---|---:|\n`;
  for (const [k,v] of Object.entries(r.summary)) md += `| ${k} | ${v} |\n`;
  md += `\n## Normal vs Playground\n\n`;
  md += `Baseline: ${r.baseline}\n\nPlayground: ${r.application}\n\n`;
  md += `## Findings\n\n`;
  r.findings.forEach((f,i)=>{
    md += `### ${i+1}. ${f.title}\n\n`;
    md += `- Category: ${f.category}\n- Severity: ${f.severity}\n- AI confidence: ${f.confidence}%\n\n`;
    md += `**Observed:** ${f.observedBehavior}\n\n**Expected:** ${f.expectedBehavior}\n\n**Evidence:**\n\n${f.evidence}\n\n**Recommendation:** ${f.recommendation}\n\n`;
  });
  md += `## AI Decisions\n\n`;
  r.decisions.forEach(d=>md+=`- Step ${d.step}: **${d.action.action}** → \`${d.action.targetId}\` — ${d.action.reason || ""}\n`);
  return md;
}

function buildHtml(r) {
  const findingHtml = r.findings.length ? r.findings.map((f,i)=>`
  <article class="finding">
    <div class="sev">${esc(f.severity)}</div>
    <h2>${i+1}. ${esc(f.title)}</h2>
    <p><b>Category:</b> ${esc(f.category)} &nbsp; <b>AI confidence:</b> ${esc(f.confidence)}%</p>
    <div class="cols">
      <div><h3>Observed behavior</h3><p>${esc(f.observedBehavior)}</p></div>
      <div><h3>Expected behavior</h3><p>${esc(f.expectedBehavior)}</p></div>
    </div>
    <h3>Evidence</h3><pre>${esc(f.evidence)}</pre>
    <h3>Recommendation</h3><p>${esc(f.recommendation)}</p>
    <h3>Normal vs Playground comparison</h3>
    <pre>${esc(JSON.stringify(f.baseline || {}, null, 2))}</pre>
  </article>`).join("") : `<div class="empty">No high-confidence chaos finding was produced in this run.</div>`;

  const decisions = r.decisions.map(d=>`
    <tr><td>${d.step}</td><td>${esc(d.action.action)}</td><td>${esc(d.action.targetId)}</td><td>${esc(d.action.value || "")}</td><td>${esc(d.action.reason || "")}</td></tr>
  `).join("");

  return `<!doctype html><html><head><meta charset="utf-8"><title>Autonomous AI Chaos QA</title>
  <style>
  body{font-family:Inter,Arial,sans-serif;margin:0;background:#f5f7fb;color:#172033}
  header{background:#17233c;color:white;padding:32px 6vw}
  main{max-width:1200px;margin:28px auto;padding:0 20px}
  .stats{display:grid;grid-template-columns:repeat(5,1fr);gap:14px}
  .stat{background:white;border-radius:12px;padding:20px;box-shadow:0 2px 10px #0001}.stat b{display:block;font-size:30px;margin-top:8px}
  .finding{background:white;margin:22px 0;padding:24px;border-radius:14px;box-shadow:0 2px 12px #0001;border-left:7px solid #c026d3}
  .sev{display:inline-block;padding:5px 10px;border-radius:20px;background:#fef3c7;font-weight:bold}
  .cols{display:grid;grid-template-columns:1fr 1fr;gap:18px}.cols>div{padding:16px;background:#f8fafc;border-radius:10px}
  pre{white-space:pre-wrap;background:#111827;color:#e5e7eb;padding:16px;border-radius:9px;overflow:auto}
  table{width:100%;border-collapse:collapse;background:white}.card{padding:20px;background:white;border-radius:14px;margin:22px 0;box-shadow:0 2px 12px #0001}
  th,td{padding:12px;border-bottom:1px solid #e5e7eb;text-align:left}th{background:#eef2ff}
  .empty{background:white;padding:25px;border-radius:12px}
  @media(max-width:800px){.stats,.cols{grid-template-columns:1fr 1fr}}
  </style></head><body>
  <header><h1>🤖 Autonomous AI Chaos QA</h1><p>AI-driven autonomous application exploration and chaos discovery report</p><p>Generated: ${esc(r.generatedAt)}</p></header>
  <main>
  <div class="stats">
    <div class="stat">AI actions<b>${r.summary.actions}</b></div>
    <div class="stat">Observations<b>${r.summary.observations}</b></div>
    <div class="stat">Chaos findings<b>${r.summary.chaosFindings}</b></div>
    <div class="stat">Passed actions<b>${r.summary.passedActions}</b></div>
    <div class="stat">Handled failures<b>${r.summary.failedActions}</b></div>
  </div>
  <div class="card"><h2>Normal vs Playground</h2><p><b>Normal baseline:</b> ${esc(r.baseline)}</p><p><b>Chaos playground:</b> ${esc(r.application)}</p><p>The AI explores the playground while the report preserves baseline evidence so behavioral differences can be reviewed.</p></div>
  <h2>Chaos Findings</h2>${findingHtml}
  <div class="card"><h2>AI Decision Timeline</h2><table><tr><th>Step</th><th>Action</th><th>Target</th><th>Value</th><th>Reason</th></tr>${decisions}</table></div>
  </main></body></html>`;
}
