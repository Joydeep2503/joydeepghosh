"""
Orchestrator
------------
The single autonomous pipeline the FastAPI backend kicks off in the
background for every run:

  discover endpoints -> AI decides scenarios -> execute chaos scenarios ->
  inject a fault & retry until the API recovers (live) -> AI explains why it
  failed and how it recovered -> AI generates the overall resilience report

Each phase updates the run's status in SQLite so the frontend can show
exactly what the agent is doing in real time.
"""
from backend import database as db
from backend import discovery
from backend import ai_planner
from backend import chaos_engine
from backend import recovery_engine
from backend import recovery_analyzer
from backend import ai_analyzer


def autonomous_run(run_id, target_url, verify_ssl=True):
    try:
        # 1. AI Injects Failure (prep step: discover what's even testable).
        # Works against both structured APIs (OpenAPI discovery) and plain
        # URLs with no API spec (generic single-URL fallback) - see
        # discovery.py. This can never raise "no endpoints" since generic
        # mode always returns at least the target URL itself.
        db.update_status(run_id, "discovering")
        endpoints, discovery_mode, effective_base_url = discovery.discover_endpoints(
            target_url, verify_ssl=verify_ssl
        )

        # AI decides which scenarios apply to this specific target
        db.update_status(run_id, "planning")
        plan = ai_planner.plan_scenarios(target_url, endpoints, discovery_mode)
        plan["discovery_mode"] = discovery_mode
        plan["effective_base_url"] = effective_base_url
        db.set_run_plan(run_id, plan, endpoints)

        # 2 & 3. AI Observes Behavior / AI Validates Resilience
        db.update_status(run_id, "running")
        chaos_engine.execute_run(
            run_id, effective_base_url, plan["scenarios"], endpoints,
            plan.get("chaos_hook_path"), verify_ssl=verify_ssl,
        )

        # Fault Injection & Recovery Monitoring: inject a fault into the
        # target and retry until it recovers (or a max-attempt budget runs
        # out), streaming every probe to SQLite live. This runs regardless
        # of which of the 3 scenarios the AI picked above, since "inject a
        # fault and retry until it recovers" is a core agent capability, not
        # an optional scenario. Skipped only if no GET endpoint exists to
        # safely poll (logged, not an error).
        db.update_status(run_id, "recovering")
        recovery_result = recovery_engine.run_recovery_scenario(
            run_id, effective_base_url, endpoints, plan.get("chaos_hook_path"), verify_ssl
        )
        if recovery_result:
            db.update_status(run_id, "analyzing_recovery")
            analysis = recovery_analyzer.analyze_recovery(recovery_result)
            db.save_recovery_summary(
                run_id, recovery_result["endpoint"], recovery_result["fault_type"],
                recovery_result["outcome"], recovery_result["recovery_time_ms"],
                recovery_result["total_attempts"], analysis["root_cause"],
                analysis["recovery_explanation"], analysis["recommendations"],
            )

        # 4 & 5. AI Identifies Weaknesses / AI Generates Reports
        db.update_status(run_id, "analyzing")
        ai_analyzer.generate_report(run_id)

        db.finish_run(run_id, status="completed")
    except Exception as exc:  # noqa: BLE001
        db.finish_run(run_id, status="failed", error=str(exc))
