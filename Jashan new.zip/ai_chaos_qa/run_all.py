"""
Convenience launcher: starts the demo AUT (port 9000), the FastAPI backend
(port 8000), and the Streamlit frontend (port 8501) together.

Usage:  python run_all.py
Stop with Ctrl+C (all three processes will be terminated).

Note: this assumes 'ollama serve' is already running separately and that
you've pulled a model (see README.md).
"""
import subprocess
import sys
import time
import signal

PROCS = []


def start(cmd, name):
    print(f"Starting {name}: {' '.join(cmd)}")
    p = subprocess.Popen(cmd)
    PROCS.append((name, p))
    return p


def shutdown(*_):
    print("\nShutting down...")
    for name, p in PROCS:
        print(f"  stopping {name}")
        p.terminate()
    sys.exit(0)


if __name__ == "__main__":
    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    start([sys.executable, "-m", "uvicorn", "target_app.main:app", "--port", "9000"], "Demo AUT (port 9000)")
    time.sleep(1)
    start([sys.executable, "-m", "uvicorn", "backend.main:app", "--port", "8000"], "Backend API (port 8000)")
    time.sleep(1)
    start([sys.executable, "-m", "streamlit", "run", "frontend/app.py"], "Streamlit UI (port 8501)")

    print("\nAll services starting. Streamlit will open at http://localhost:8501")
    print("Press Ctrl+C to stop everything.\n")

    while True:
        time.sleep(1)
        for name, p in PROCS:
            if p.poll() is not None:
                print(f"[{name}] exited with code {p.returncode}")
                shutdown()
