import { defineConfig } from "@playwright/test";
export default defineConfig({
  testDir: "./tests",
  timeout: 60000,
  use: { headless: true },
  reporter: "list",
  webServer: {
    command: "node server.js",
    url: "http://127.0.0.1:8080/chaos-playground/",
    reuseExistingServer: true,
    timeout: 10000
  }
});
