import Groq from "groq-sdk";
import dotenv from "dotenv";
dotenv.config();
const groq = new Groq({
 apiKey: process.env.GROQ_API_KEY,
 timeout: 30_000,
 maxRetries: 0,
});
const sleep = (ms: number) =>
 new Promise((resolve) => setTimeout(resolve, ms));
const MODEL = process.env.MODEL || "openai/gpt-oss-120b";
const SYSTEM_PROMPT =
  "You are a deterministic autonomous QA action selector. " +
  "Return one compact JSON object only. Use only ids and values present or " +
  "clearly implied by the supplied page state; never invent selectors. " +
  "Avoid every action signature in history. Ordinary validation is expected; " +
  "prefer untested user journeys and meaningful boundary states.";
async function askGroqOnce(prompt: string): Promise<string> {
 const response = await groq.chat.completions.create({
   model: MODEL,
   messages: [
     {
       role: "system",
       content: SYSTEM_PROMPT,
     },
     {
       role: "user",
       content: prompt,
     },
   ],
   /*
    * GPT-OSS 120B:
    * Use Structured Outputs instead of JSON Object Mode.
    */
   /*
    * GPT-OSS supports reasoning effort.
    * Medium gives the agent enough reasoning
    * without making every decision unnecessarily slow.
    */
   reasoning_effort: "low",
   /*
    * Keep reasoning hidden from our application.
    */
   reasoning_format: "hidden",
   temperature: 0,
    max_completion_tokens: 180,
 });
 return response.choices[0]?.message?.content || "";
}
export async function askLLM(prompt: string): Promise<string> {
  const configuredRetries = Number(process.env.LLM_MAX_RETRIES || 1);
  const MAX_RETRIES = Number.isFinite(configuredRetries)
    ? Math.max(1, Math.min(3, configuredRetries))
    : 1;
 for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
   try {
     console.log(
       `\n🤖 Asking GPT-OSS 120B... attempt ${attempt}/${MAX_RETRIES}`
     );
     const output = await askGroqOnce(prompt);
     console.log(
       "\n========== GPT-OSS OUTPUT =========="
     );
     console.log(output);
     console.log(
       "====================================\n"
     );
     if (!output.trim()) {
       console.warn(
         "⚠️ GPT-OSS returned an empty response."
       );
       return JSON.stringify({
         action: "none",
         targetId: null,
         value: null,
         reason: "AI returned an empty response",
         aiAvailable: false,
       });
     }
     return output;
   } catch (error: any) {
     console.error(
       `\n❌ GPT-OSS ERROR - attempt ${attempt}/${MAX_RETRIES}`
     );
     console.error(
       "Status:",
       error?.status
     );
     console.error(
       "Message:",
       error?.message || error
     );
     /*
      * Rate limit
      */
     if (error?.status === 429) {
       if (attempt < MAX_RETRIES) {
         const retryAfter =
           Number(
             error?.headers?.["retry-after"]
           ) ||
           Number(
             error?.headers?.get?.(
               "retry-after"
             )
           ) ||
            10;
         const waitTime = Math.min(
           Math.max(retryAfter * 1000, 5000),
           30000
         );
         console.log(
           `⏳ Waiting ${waitTime / 1000}s...`
         );
         await sleep(waitTime);
         continue;
       }
       return JSON.stringify({
         action: "none",
         targetId: null,
         value: null,
          reason:
            "AI rate limit reached for this model or organization. " +
            "Exploration stopped safely; wait for the provider reset or use a model with available quota.",
         aiAvailable: false,
          rateLimited: true,
       });
     }
     /*
      * Invalid key
      */
     if (error?.status === 401) {
       return JSON.stringify({
         action: "none",
         targetId: null,
         value: null,
         reason: "Invalid Groq API key",
         aiAvailable: false,
       });
     }
     /*
      * Other error
      */
     return JSON.stringify({
       action: "none",
       targetId: null,
       value: null,
       reason:
         error?.message ||
         "AI request failed",
       aiAvailable: false,
     });
   }
 }
 return JSON.stringify({
   action: "none",
   targetId: null,
   value: null,
   reason: "AI request unavailable",
   aiAvailable: false,
 });
}
/*
* Keep backwards compatibility with
* existing imports in the project.
*/
export const askGroq = askLLM;