import { defineConfig } from "@playwright/test";
export default defineConfig({
 testDir: "./tests",
 timeout: 120000, // Increased timeout for slower visible testing
 use: {
   headless: false, // ✨ SHOW BROWSER WINDOW
   slowMo: 800, // ✨ SLOW DOWN ACTIONS (ms between each action)
   trace: "on-first-retry", // Record trace for debugging
   video: "on-first-retry", // ✨ RECORD VIDEO
   screenshot: "only-on-failure", // Screenshot on errors
 },
 reporter: "list",
 webServer: {
   command: "node server.js",
   url: "http://127.0.0.1:8080/chaos-playground/",
   reuseExistingServer: true,
   timeout: 10000
 }
});