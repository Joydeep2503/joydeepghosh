import fs from "node:fs/promises";

export type PersistedAction = {
  pageUrl: string;
  action: string;
  targetId?: string;
  value?: string;
  timestamp: string;
};

const MEMORY_FILE = "reports/exploration-memory.json";

export function actionSignature(
  pageUrl: string,
  action: {
    action?: string;
    targetId?: string;
    value?: string;
  }
): string {
  return [
    pageUrl,
    action.action || "",
    action.targetId || "",
    action.value || "",
  ].join("|");
}

export async function loadExplorationMemory(
  filePath = MEMORY_FILE
): Promise<PersistedAction[]> {
  try {
    const raw = await fs.readFile(filePath, "utf8");
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed?.actions) ? parsed.actions : [];
  } catch {
    return [];
  }
}

export async function saveExplorationMemory(
  actions: PersistedAction[],
  filePath = MEMORY_FILE
): Promise<void> {
  await fs.mkdir("reports", { recursive: true });
  await fs.writeFile(
    filePath,
    JSON.stringify(
      {
        updatedAt: new Date().toISOString(),
        actions,
      },
      null,
      2
    ),
    "utf8"
  );
}