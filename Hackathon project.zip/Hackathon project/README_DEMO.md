## 60-second mentor explanation

"StayNest is our intentionally buggy flight/booking-style playground. The AI agent reads the DOM, decides what to interact with, executes actions through Playwright, records the before/after state, and analyzes the result. We do not define normal locators for every test case; the AI receives the available targets dynamically. We also have a safety net of boundary probes for reproducible high-value defects. The final report converts those observations into severity, evidence, expected behavior and recommendations."

The important distinction is:
AI exploration -> observation -> anomaly/edge-case detection -> report.
