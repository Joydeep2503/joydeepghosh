import { test } from "@playwright/test";
import fs from "fs";
import path from "path";
import { askAgent } from "../agents/ai.js";
import { analyzeObservation } from "../agents/heuristics.js";
const APP_URL = process.env.APP_URL || "http://127.0.0.1:8080/chaos-playground/";
const MAX_ACTIONS = Number(process.env.MAX_AI_ACTIONS || 8);
const OUT = path.resolve("reports");
function ensureReports() {
 fs.mkdirSync(OUT, { recursive: true });
}
// FIX #1: Make it async and properly handle the Promise
async function domSnapshot(page) {
 try {
   return await page.locator("body").innerText();
 } catch {
   return "";
 }
}
async function describeTargets(page) {
 return page.locator("button,input,select,a").evaluateAll(els =>
   els.map((e,i) => ({
     id: e.id || e.getAttribute("data-testid") || `element-${i}`,
     tag: e.tagName.toLowerCase(),
     text: (e.innerText || e.getAttribute("aria-label") || e.getAttribute("placeholder") || "").trim().slice(0,100),
     type: e.getAttribute("type"),
     value: e.value || ""
   })).slice(0,80)
 );
}
async function execute(page, action) {
 if (!action || !action.action || action.action === "none" || action.action === "stop") return false;
 const targets = await describeTargets(page);
 const target = targets.find(x => x.id === action.targetId);
 if (!target) return false;
 // FIX #2: Removed invalid CSS.escape() and redundant ternary operator
 // Playwright handles ID escaping internally
 const locator = page.locator(`#${target.id}`);
 if (action.action === "click") await locator.click({ timeout: 5000 });
 else if (action.action === "fill" && target.tag === "input") await locator.fill(String(action.value ?? ""));
 else if (action.action === "press") await locator.press(String(action.value || "Enter"));
 else if (action.action === "select" && target.tag === "select") await locator.selectOption(String(action.value));
 else return false;
 return true;
}
test("Autonomous AI Chaos QA", async ({ page }) => {
 ensureReports();
 const observations = [];
 const findings = [];
 await page.goto(APP_URL);
 await page.waitForLoadState("domcontentloaded");
 // Seed the explorer into the booking/payment flow so the demo reliably exercises a meaningful workflow.
 await page.locator("#filter-all").click();
 await page.locator(".book-btn").first().click();
 await page.locator("#to-payment").click();
 // Deterministic boundary probes ensure the demo can find real bugs even if the LLM is rate-limited.
 const probes = [
   async () => {
     const before = await domSnapshot(page), urlBefore = page.url();
     await page.locator("#card").fill("123");
     await page.locator("#expiry").fill("01/20");
     await page.locator("#cvv").fill("1");
     await page.locator("#pay-btn").click();
     await page.waitForTimeout(250);
     const after = await domSnapshot(page), urlAfter = page.url();
     const action = {action:"fill", targetId:"card", value:"123", reason:"Boundary probe: deliberately invalid card data."};
     observations.push({action,before:before.slice(-2500),after:after.slice(-2500),urlBefore,urlAfter});
     findings.push(...analyzeObservation({before,after,action,urlBefore,urlAfter}));
     // Return to payment for the next probe if the app confirmed.
     if (await page.locator("#back-home").count()) {
       await page.goto(APP_URL);
       await page.locator(".book-btn").first().click();
       await page.locator("#to-payment").click();
     }
   },
   async () => {
     const before = await domSnapshot(page), urlBefore = page.url();
     await page.locator("#card").fill("4111111111111111");
     await page.locator("#expiry").fill("12/30");
     await page.locator("#cvv").fill("123");
     await page.locator("#pay-btn").click();
     const after = await domSnapshot(page), urlAfter = page.url();
     const action = {action:"click", targetId:"pay-btn", value:null, reason:"Repeated-submission probe on payment control."};
     observations.push({action,before:before.slice(-2500),after:after.slice(-2500),urlBefore,urlAfter});
     findings.push(...analyzeObservation({before,after,action,urlBefore,urlAfter}));
   }
 ];
 for (const probe of probes) await probe();
 // AI exploration is additive. If Groq is unavailable/rate-limited, deterministic probes still produce a report.
 console.log(`\n🤖 Starting AI exploration (${MAX_ACTIONS} actions max)...`);
 console.log(`API Key present: ${process.env.GROQ_API_KEY ? "✅ YES" : "❌ NO"}`);
 const actionHistory = [];
 for (let i=0; i<MAX_ACTIONS; i++) {
   const before = await domSnapshot(page);
   const targets = await describeTargets(page);
   const historyText = actionHistory.length
     ? actionHistory.map((a, idx) => `${idx+1}. ${a.action} on "${a.targetId}" with value "${a.value}"`).join("\n")
     : "(none yet)";
   const prompt = fs.readFileSync("prompts/chaos-agent.txt","utf8") +
     `\n\nCURRENT URL:\n${page.url()}\n\nRECENT UI TEXT:\n${before.slice(-6000)}\n\nAVAILABLE TARGETS:\n${JSON.stringify(targets)}` +
     `\n\nACTIONS ALREADY TRIED THIS RUN (do NOT repeat these unless deliberately re-testing a fixed bug):\n${historyText}` +
     `\n\nPick a DIFFERENT action/target/value than what's already been tried above, to maximize coverage.`;
   console.log(`\n[Action ${i+1}/${MAX_ACTIONS}] Calling AI agent...`);
   const action = await askAgent(prompt);
   if (!action) {
     console.log(`⚠️  Action ${i+1}: AI returned null (API issue or rate limit)`);
     break;
   }
   console.log(`✅ Action ${i+1}: AI chose: ${action.action} on ${action.targetId} (reason: ${action.reason})`);
   if (action.action === "stop" || action.action === "none") {
     console.log(`⏹️  Action ${i+1}: AI decided to stop`);
     break;
   }
   const urlBefore = page.url();
   const executed = await execute(page, action);
   if (!executed) {
     console.log(`❌ Action ${i+1}: Failed to execute (target not found)`);
     continue;
   }
   actionHistory.push(action);
   console.log(`🎬 Action ${i+1}: Executed successfully`);
   await page.waitForTimeout(300);
   const after = await domSnapshot(page);
   const urlAfter = page.url();
   observations.push({
     action,
     before: before.slice(-2500),
     after: after.slice(-2500),
     urlBefore,
     urlAfter
   });
   const actionFindings = analyzeObservation({before,after,action,urlBefore,urlAfter});
   if (actionFindings.length > 0) {
     console.log(`🐛 Action ${i+1}: Found ${actionFindings.length} issue(s)`);
   }
   findings.push(...actionFindings);
 }
 console.log(`\n✅ AI exploration completed\n`);
 // De-duplicate findings by title/category.
 const unique = [...new Map(findings.map(f => [`${f.title}|${f.category}`, f])).values()];
 const report = {
   generatedAt: new Date().toISOString(),
   appUrl: APP_URL,
   summary: {
     actions: observations.length,
     observations: observations.length,
     chaosFindings: unique.length,
     edgeCases: unique.filter(f => f.category !== "NAVIGATION").length
   },
   findings: unique,
   observations
 };
 fs.writeFileSync(path.join(OUT,"chaos-report.json"), JSON.stringify(report,null,2));
 console.log(`\nFINAL CHAOS QA REPORT\nTotal findings: ${unique.length}\nJSON: reports/chaos-report.json`);
});