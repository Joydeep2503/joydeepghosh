import "dotenv/config";
import OpenAI from "openai";

const apiKey = process.env.GROQ_API_KEY;
const model = process.env.GROQ_MODEL || "openai/gpt-oss-120b";
const client = apiKey ? new OpenAI({ apiKey, baseURL: "https://api.groq.com/openai/v1" }) : null;

function extractJson(text) {
  if (!text) return null;
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
  const candidate = fenced ? fenced[1] : text;
  const start = candidate.indexOf("{");
  const end = candidate.lastIndexOf("}");
  if (start < 0 || end < start) return null;
  try { return JSON.parse(candidate.slice(start, end + 1)); } catch { return null; }
}

export async function askAgent(prompt) {
  if (!client) return null;
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const response = await client.chat.completions.create({
        model,
        temperature: 0.2,
        max_tokens: 500,
        messages: [
          { role: "system", content: "Return only JSON. No markdown. No commentary." },
          { role: "user", content: prompt }
        ]
      });
      const text = response.choices?.[0]?.message?.content || "";
      const parsed = extractJson(text);
      if (parsed) return parsed;
      return null;
    } catch (err) {
      const status = err?.status;
      if (status === 429 && attempt < 3) {
        await new Promise(r => setTimeout(r, attempt * 5000));
        continue;
      }
      console.log(`AI request failed: ${err?.message || err}`);
      return null;
    }
  }
  return null;
}
