import fs from "node:fs/promises";
import path from "node:path";

export type MemoryEntry = {
  signature: string;
  action: string;
  targetId?: string;
  value?: string;
  status: "executed" | "failed" | "skipped";
  lastSeen: string;
  timesSeen: number;
};

export type ExplorationMemory = {
  version: 1;
  targetUrl: string;
  entries: MemoryEntry[];
};

const emptyMemory = (targetUrl: string): ExplorationMemory => ({
  version: 1,
  targetUrl,
  entries: [],
});

export const actionSignature = (action: {
  action?: string;
  targetId?: string;
  value?: string;
}) => [action.action ?? "", action.targetId ?? "", action.value ?? ""].join("|");

export async function loadExplorationMemory(
  filePath = "reports/exploration-memory.json",
  targetUrl = "",
): Promise<ExplorationMemory> {
  try {
    const raw = JSON.parse(await fs.readFile(filePath, "utf8"));
    if (
      raw?.version === 1 &&
      Array.isArray(raw.entries) &&
      (!targetUrl || !raw.targetUrl || raw.targetUrl === targetUrl)
    ) {
      return { ...raw, targetUrl: raw.targetUrl || targetUrl };
    }
  } catch {
    // First run or an old/corrupt memory file: start clean and keep the run alive.
  }
  return emptyMemory(targetUrl);
}

export function hasExplored(
  memory: ExplorationMemory,
  action: { action?: string; targetId?: string; value?: string },
): boolean {
  return memory.entries.some((entry) => entry.signature === actionSignature(action));
}

export function rememberAction(
  memory: ExplorationMemory,
  action: { action?: string; targetId?: string; value?: string },
  status: MemoryEntry["status"],
): void {
  const signature = actionSignature(action);
  const current = memory.entries.find((entry) => entry.signature === signature);
  if (current) {
    current.lastSeen = new Date().toISOString();
    current.timesSeen += 1;
    current.status = status;
    return;
  }
  memory.entries.push({
    signature,
    action: action.action || "unknown",
    targetId: action.targetId,
    value: action.value,
    status,
    lastSeen: new Date().toISOString(),
    timesSeen: 1,
  });
}

export async function saveExplorationMemory(
  memory: ExplorationMemory,
  filePath = "reports/exploration-memory.json",
): Promise<void> {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await fs.writeFile(filePath, JSON.stringify(memory, null, 2), "utf8");
}