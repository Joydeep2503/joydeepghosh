require("dotenv").config();

if (!process.env.AI_API_KEY || process.env.AI_API_KEY === "PASTE_YOUR_API_KEY_HERE") {
  console.error("ERROR: AI_API_KEY is missing.");
  console.error("Open .env and paste your API key into AI_API_KEY=...");
  process.exit(1);
}

console.log("Preflight OK: API key is configured.");
