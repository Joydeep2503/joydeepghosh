// Reports are generated directly by tests/chaos.spec.js after every run.
// This command is intentionally kept as a safe entry point.
const fs = require("fs");
if (!fs.existsSync("reports/chaos-report.html")) {
  console.log("No report exists yet. Run: npm run qa");
} else {
  console.log("Latest report: reports/chaos-report.html");
}
