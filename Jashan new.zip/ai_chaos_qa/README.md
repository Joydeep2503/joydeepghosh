# AI Chaos QA

A fully **autonomous** resilience-testing agent. Point it at a target API and
it does everything itself:

1. **Discovers** the target's REST endpoints from its OpenAPI schema (no hardcoded endpoint list anywhere in this codebase)
2. **Decides** which chaos scenarios actually apply, using a local LLM (Ollama) — no manual scenario checkboxes
3. **Injects** the chosen faults and **observes** behavior in real time
4. **Identifies** weaknesses (anomaly detection)
5. **Generates** an AI resilience report automatically the moment the run finishes

**Tech stack**: Streamlit (frontend) · FastAPI (backend) · Ollama (local LLM) · SQLite (database)
Runs entirely on your machine — no cloud, no CI/CD, no containers required.

---

## 1. Prerequisites

- Python 3.10+
- [Ollama](https://ollama.com) installed locally

```bash
ollama pull llama3.2
ollama serve      # leave running in its own terminal
```

> If Ollama isn't running, the agent still works end-to-end — scenario
> selection falls back to a transparent rule-based plan, and the report
> falls back to a rule-based summary. You'll just miss the LLM's reasoning.
> To use a different model: `export OLLAMA_MODEL=mistral` before starting the backend.

---

## 2. Project structure

```
ai_chaos_qa/
├── target_app/          # Sample "Application Under Test" (AUT) — a fragile demo API to test against
│   └── main.py
├── backend/               # FastAPI autonomous agent
│   ├── main.py             # REST API (the backend you access directly)
│   ├── discovery.py        # dynamically parses the target's /openapi.json — no static endpoint list
│   ├── ai_planner.py        # asks Ollama which chaos scenarios apply, given the discovered endpoints
│   ├── orchestrator.py      # runs the full pipeline: discover -> plan -> execute -> report
│   ├── chaos_engine.py      # the 3 fault-injection scenarios + anomaly detection
│   ├── ai_analyzer.py       # Ollama-powered report generation
│   ├── database.py          # SQLite persistence
│   ├── models.py
│   └── config.py
├── frontend/
│   └── app.py               # Streamlit dashboard (thin client over the backend API)
├── data/                   # chaos_qa.db (SQLite file) created here automatically
├── requirements.txt
├── run_all.py               # optional convenience launcher for all 3 services
└── README.md
```

---

## 3. Setup

```bash
cd ai_chaos_qa
python -m venv venv
source venv/bin/activate        # on Windows: venv\Scripts\activate
pip install -r requirements.txt
```

---

## 4. Run the app

You need **3 processes** running at once (plus `ollama serve` from step 1).
Open 3 terminals (venv activated in each), or use `run_all.py`.

### Terminal 1 — the demo target application (AUT)

```bash
uvicorn target_app.main:app --port 9000 --reload
```

A small, intentionally fragile sample e-commerce API to demo against.
Point the agent at your own API later — the only requirement is that it
exposes an OpenAPI schema at `/openapi.json` (every FastAPI app does this
automatically; for other frameworks, make sure Swagger/OpenAPI is enabled).

### Terminal 2 — the FastAPI backend (the agent itself)

```bash
uvicorn backend.main:app --port 8000 --reload
```

This is a **standalone REST API** — you don't need the Streamlit UI to use
it. Access it directly:
- Swagger UI: **http://localhost:8000/docs**
- ReDoc: **http://localhost:8000/redoc**
- Or call it with curl/Postman, e.g.:
  ```bash
  curl -X POST http://localhost:8000/api/runs/autostart \
       -H "Content-Type: application/json" \
       -d '{"target_url": "http://localhost:9000"}'
  ```

### Terminal 3 — the Streamlit dashboard (optional UI)

```bash
streamlit run frontend/app.py
```

Opens at **http://localhost:8501**.

### Option B: one command

```bash
python run_all.py
```
(Still run `ollama serve` separately first.)

---

## 5. Using the app

1. Enter the **Target Base URL** in the sidebar (defaults to the demo AUT, `http://localhost:9000`).
2. *(Optional)* Click **"Preview discovered endpoints"** to sanity-check what the agent found.
3. Click **"🚀 Run Autonomous Chaos Test"**. That's the only decision you make — from here the agent:
   - discovers endpoints from `/openapi.json`
   - asks the local LLM which of the 3 scenarios apply (and whether a chaos-outage hook exists)
   - runs them, streaming results into SQLite live
   - automatically generates the AI resilience report the moment the run finishes
4. The **Live Run & Results** tab shows the agent's phase (discovering → planning → running → analyzing → completed), its chosen scenarios + rationale, and live results as they land.
5. The **AI Report** tab shows the resilience score, findings, and recommendations — generated automatically, no button needed (a "Force regenerate" option is available if you want the LLM to re-analyze).
6. **Run History** lists past runs with their chosen scenarios; click **View** to reopen one.

### Testing your own API

Just change the **Target URL** — nothing else to configure. The agent will
discover your API's endpoints and decide scenarios on its own. If you want
the **Partial Outage** scenario to run against your API, expose a POST
endpoint whose path contains a keyword like `chaos`, `outage`, `toggle`,
`fault`, or `simulate`, and have it accept `{"enable": true|false}` to toggle
a simulated downstream failure (see `target_app/main.py`'s
`/chaos/toggle-outage` for a reference implementation). If no such hook is
found, the agent simply skips that scenario — no error.

### Testing a plain URL (no OpenAPI spec) — e.g. a public website

The agent works against two kinds of targets:

| Target has an OpenAPI schema at `/openapi.json`? | Mode | What runs |
|---|---|---|
| Yes (any FastAPI app, or another framework with OpenAPI/Swagger enabled) | **openapi** | All 3 scenarios the AI decides apply, against every discovered endpoint |
| No (a plain website, a non-FastAPI service, any page URL) | **generic** | Only *API Failure Injection* (timeout/status probing) against the exact URL given — the other 2 scenarios need API structure a plain page doesn't have |

You don't need to configure which mode to use — the agent tries OpenAPI
discovery first and automatically falls back to generic mode if that fails
for any reason (404, no OpenAPI schema, connection/SSL error, etc.). Just
paste any URL, e.g.:

```
https://www.geeksforgeeks.org/courses/dsa-system-design-live-sde-interview-course
```

and the Live Run tab will show `mode: generic` along with the AI plan
explaining why only failure/timeout probing ran.

### Corporate proxy / SSL certificate errors

If you see something like:

```
SSLCertVerificationError: unable to get local issuer certificate
```

this is almost always a corporate network intercepting HTTPS with its own
proxy certificate that Python doesn't trust (even though your browser does).
Two ways to fix it:

- **Quick fix**: uncheck **"Verify SSL certificates"** in the sidebar before
  running (or pass `"verify_ssl": false` to `/api/runs/autostart` /
  `/api/discover`). Only do this for targets/networks you trust — it
  disables TLS verification for that run.
- **Proper fix**: get your corporate root CA `.pem` from IT and set it before
  starting the backend, so `requests` trusts it automatically:
  ```bash
  export REQUESTS_CA_BUNDLE=/path/to/corporate-ca-bundle.pem   # Mac/Linux
  set REQUESTS_CA_BUNDLE=C:\path\to\corporate-ca-bundle.pem     # Windows
  ```

---

## 6. How it maps to the proposal

| Slide step | Implementation |
|---|---|
| Discovery (no static config) | `backend/discovery.py` parses the target's OpenAPI schema — endpoints, methods, and sample payloads are all derived at runtime |
| Scenario decision (AI, not manual) | `backend/ai_planner.py` sends the discovered endpoints to Ollama and gets back which scenarios apply + rationale |
| 1. AI Injects Failure | `backend/chaos_engine.py` — timeouts, extreme/malformed payloads, simulated outage toggling |
| 2. AI Observes Behavior | Every probe records status code, latency and body to SQLite immediately; Streamlit polls live |
| 3. AI Validates Resilience | Classification rules check for graceful 4xx/503 vs. crashes/hangs/silent acceptance |
| 4. AI Identifies Weaknesses | Each result is flagged `is_anomaly` + a human-readable reason |
| 5. AI Generates Reports | `backend/ai_analyzer.py` runs automatically at the end of `backend/orchestrator.py`'s pipeline — no manual trigger |

---

## 7. A note on testing third-party sites

In **generic mode** the agent only ever sends GET requests (no data
mutation, no outage toggling) — but it does send several requests in a row,
including under a tight timeout and repeated back-to-back. Only point this
at sites you own or have permission to test; repeated automated requests
against a third party's production site — even read-only ones — can violate
their terms of service or look like abusive traffic. For learning/demo
purposes, prefer the bundled `target_app` or your own local/staging services.

## 8. Troubleshooting

- **"No endpoints discovered"** → the target must expose `/openapi.json`
  (automatic for FastAPI apps). Confirm the demo AUT is running on port 9000,
  or that your target URL is correct.
- **AI plan/report always shows the rule-based fallback** → make sure
  `ollama serve` is running and you've pulled the model set in
  `backend/config.py` (`OLLAMA_MODEL`, default `llama3.2`).
- **Port already in use** → change the port in the relevant `uvicorn`/
  `streamlit` command and update the URL in the Streamlit sidebar accordingly.
- **Reset all data** → stop the app and delete `data/chaos_qa.db`; it will be
  recreated on next start.
