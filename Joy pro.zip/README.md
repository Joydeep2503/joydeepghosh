# Autonomous AI Chaos QA

A self-contained hackathon demo that:

1. Opens a normal baseline website and a deliberately flawed playground.
2. Gives the AI an inventory of real DOM targets instead of allowing invented selectors.
3. Lets the AI choose different exploration actions.
4. Executes actions visibly in Chromium.
5. Never terminates the whole exploration because one AI action is invalid/unavailable.
6. Compares playground behavior with the normal baseline.
7. Generates JSON, Markdown and HTML reports automatically after every run.
8. Shows AI decisions, action success/failure, observations, findings and comparison evidence.

## One-time setup

```bash
npm install
npm run install:browsers
```

Copy `.env.example` to `.env` and put your API key in `AI_API_KEY`.

If your provider/model differs, change `AI_BASE_URL` and `AI_MODEL` in `.env`.

## Run

```bash
npm run qa
```

A visible Chromium window will open. The terminal prints every AI decision and action.

When the run finishes, open:

```text
reports/chaos-report.html
```

The report is regenerated automatically every run.

## Demo story

The `/normal-playground/` page is the expected/working baseline.

The `/chaos-playground/` page intentionally contains business-logic defects such as:

- invalid payment data can reach confirmation,
- zero/invalid guests can be accepted,
- a price filter can behave incorrectly,
- navigation/filter state can be inconsistent.

The AI does not receive a hard-coded list of bugs. It explores real targets and the report compares the same workflow/state against the baseline.

## If you already have your own application

Change only:

```text
APP_URL
BASELINE_URL
```

in `.env`.

The agent will build its target inventory from the actual DOM.
