export function analyzeObservation({before, after, action, urlBefore, urlAfter}) {
  const findings = [];
  const beforeText = (before || "").toLowerCase();
  const afterText = (after || "").toLowerCase();

  if (action?.action === "fill" && /card|payment/i.test(action?.targetId || "") && /invalid|short|abc|123/.test(action?.value || "")) {
    if (/confirmed|accepted|paid/.test(afterText)) {
      findings.push({
        title: "Invalid payment data accepted",
        severity: "CRITICAL",
        category: "PAYMENT_VALIDATION",
        confidence: 0.98,
        observedBehavior: "The application reached a successful payment/confirmation state after clearly invalid card input.",
        expectedBehavior: "Invalid payment data should be rejected and the user should remain on the payment step.",
        evidence: [`Input used: ${action.value}`, `Post-action page contains a success/payment state.`],
        recommendation: "Validate card number length/format and reject invalid payment data before confirmation."
      });
    }
  }

  if (action?.action === "click" && action?.targetId === "pay-btn" && /confirmed|booking confirmed|paid/.test(afterText)) {
    findings.push({
      title: "Payment action produced a booking confirmation",
      severity: "MEDIUM",
      category: "PAYMENT_FLOW",
      confidence: 0.82,
      observedBehavior: "The payment action transitioned directly to confirmation.",
      expectedBehavior: "The payment request should be validated and captured exactly once before confirmation.",
      evidence: ["Payment button was clicked and confirmation state appeared."],
      recommendation: "Verify payment response, prevent duplicate submissions, and confirm only after successful capture."
    });
  }

  if (urlBefore !== urlAfter && !/chaos-playground/.test(urlAfter)) {
    findings.push({
      title: "Unexpected navigation state change",
      severity: "LOW",
      category: "NAVIGATION",
      confidence: 0.78,
      observedBehavior: `URL changed from ${urlBefore} to ${urlAfter}.`,
      expectedBehavior: "Navigation should occur only when the selected action is expected to change application state.",
      evidence: [`URL before: ${urlBefore}`, `URL after: ${urlAfter}`],
      recommendation: "Verify that the action intentionally triggers this route transition."
    });
  }

  return findings;
}
