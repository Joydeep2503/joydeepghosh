import { test } from "@playwright/test";
import fs from "fs";
import path from "path";
import { askAgent } from "../agents/ai.js";
import { analyzeObservation } from "../agents/heuristics.js";

const APP_URL = process.env.APP_URL || "http://127.0.0.1:8080/chaos-playground/";
const MAX_ACTIONS = Number(process.env.MAX_AI_ACTIONS || 8);
const OUT = path.resolve("reports");

function ensureReports() {
  fs.mkdirSync(OUT, { recursive: true });
}

// FIX #1: Make it async and properly handle the Promise
async function domSnapshot(page) {
  try {
    return await page.locator("body").innerText();
  } catch {
    return "";
  }
}

async function describeTargets(page) {
  return page.locator("button,input,select,a").evaluateAll(els =>
    els.map((e,i) => ({
      id: e.id || e.getAttribute("data-testid") || `element-${i}`,
      tag: e.tagName.toLowerCase(),
      text: (e.innerText || e.getAttribute("aria-label") || e.getAttribute("placeholder") || "").trim().slice(0,100),
      type: e.getAttribute("type"),
      value: e.value || ""
    })).slice(0,80)
  );
}

async function execute(page, action) {
  if (!action || !action.action || action.action === "none" || action.action === "stop") return false;
  const targets = await describeTargets(page);
  const target = targets.find(x => x.id === action.targetId);
  if (!target) return false;

  // FIX #2: Removed invalid CSS.escape() and redundant ternary operator
  // Playwright handles ID escaping internally
  const locator = page.locator(`#${target.id}`);

  if (action.action === "click") await locator.click({ timeout: 5000 });
  else if (action.action === "fill" && target.tag === "input") await locator.fill(String(action.value ?? ""));
  else if (action.action === "press") await locator.press(String(action.value || "Enter"));
  else if (action.action === "select" && target.tag === "select") await locator.selectOption(String(action.value));
  else return false;
  return true;
}

test("Autonomous AI Chaos QA", async ({ page }) => {
  ensureReports();
  const observations = [];
  const findings = [];

  await page.goto(APP_URL);
  await page.waitForLoadState("domcontentloaded");

  // Seed the explorer into the booking/payment flow so the demo reliably exercises a meaningful workflow.
  await page.locator("#filter-all").click();
  await page.locator(".book-btn").first().click();
  await page.locator("#to-payment").click();

  // Deterministic boundary probes ensure the demo can find real bugs even if the LLM is rate-limited.
  const probes = [
    async () => {
      const before = await domSnapshot(page), urlBefore = page.url();
      await page.locator("#card").fill("123");
      await page.locator("#expiry").fill("01/20");
      await page.locator("#cvv").fill("1");
      await page.locator("#pay-btn").click();
      await page.waitForTimeout(250);
      const after = await domSnapshot(page), urlAfter = page.url();
      const action = {action:"fill", targetId:"card", value:"123", reason:"Boundary probe: deliberately invalid card data."};
      observations.push({action,before:before.slice(-2500),after:after.slice(-2500),urlBefore,urlAfter});
      findings.push(...analyzeObservation({before,after,action,urlBefore,urlAfter}));
      // Return to payment for the next probe if the app confirmed.
      if (await page.locator("#back-home").count()) {
        await page.goto(APP_URL);
        await page.locator(".book-btn").first().click();
        await page.locator("#to-payment").click();
      }
    },
    async () => {
      const before = await domSnapshot(page), urlBefore = page.url();
      await page.locator("#card").fill("4111111111111111");
      await page.locator("#expiry").fill("12/30");
      await page.locator("#cvv").fill("123");
      await page.locator("#pay-btn").click();
      const after = await domSnapshot(page), urlAfter = page.url();
      const action = {action:"click", targetId:"pay-btn", value:null, reason:"Repeated-submission probe on payment control."};
      observations.push({action,before:before.slice(-2500),after:after.slice(-2500),urlBefore,urlAfter});
      findings.push(...analyzeObservation({before,after,action,urlBefore,urlAfter}));
    }
  ];

  for (const probe of probes) await probe();

  // AI exploration is additive. If Groq is unavailable/rate-limited, deterministic probes still produce a report.
  for (let i=0; i<MAX_ACTIONS; i++) {
    const before = await domSnapshot(page);
    const targets = await describeTargets(page);
    const prompt = fs.readFileSync("prompts/chaos-agent.txt","utf8") +
      `\n\nCURRENT URL:\n${page.url()}\n\nRECENT UI TEXT:\n${before.slice(-6000)}\n\nAVAILABLE TARGETS:\n${JSON.stringify(targets)}`;
    const action = await askAgent(prompt);
    if (!action || action.action === "stop" || action.action === "none") break;

    const urlBefore = page.url();
    const executed = await execute(page, action);
    if (!executed) continue;
    await page.waitForTimeout(300);
    const after = await domSnapshot(page);
    const urlAfter = page.url();

    observations.push({
      action,
      before: before.slice(-2500),
      after: after.slice(-2500),
      urlBefore,
      urlAfter
    });
    findings.push(...analyzeObservation({before,after,action,urlBefore,urlAfter}));
  }

  // De-duplicate findings by title/category.
  const unique = [...new Map(findings.map(f => [`${f.title}|${f.category}`, f])).values()];
  const report = {
    generatedAt: new Date().toISOString(),
    appUrl: APP_URL,
    summary: {
      actions: observations.length,
      observations: observations.length,
      chaosFindings: unique.length,
      edgeCases: unique.filter(f => f.category !== "NAVIGATION").length
    },
    findings: unique,
    observations
  };

  fs.writeFileSync(path.join(OUT,"chaos-report.json"), JSON.stringify(report,null,2));
  console.log(`\nFINAL CHAOS QA REPORT\nTotal findings: ${unique.length}\nJSON: reports/chaos-report.json`);
});
