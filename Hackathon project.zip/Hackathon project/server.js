import express from "express";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 8080;

app.use(express.json());
app.use("/chaos-playground", express.static(path.join(__dirname, "chaos-playground")));

app.get("/", (_req, res) => {
  res.redirect("/chaos-playground/");
});

app.listen(PORT, () => {
  console.log(`Chaos Playground running at http://127.0.0.1:${PORT}/chaos-playground/`);
});
