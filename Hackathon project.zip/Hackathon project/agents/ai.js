import "dotenv/config";
import OpenAI from "openai";
const apiKey = process.env.GROQ_API_KEY;
const model = process.env.GROQ_MODEL || "openai/gpt-oss-120b";
const client = apiKey ? new OpenAI({ apiKey, baseURL: "https://api.groq.com/openai/v1" }) : null;
function extractJson(text) {
  if (!text) return null;
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
  const candidate = fenced ? fenced[1] : text;
  const start = candidate.indexOf("{");
  const end = candidate.lastIndexOf("}");
  if (start < 0 || end < start) return null;
  try { return JSON.parse(candidate.slice(start, end + 1)); } catch { return null; }
}
export async function askAgent(prompt) {
  if (!client) {
    console.log(`❌ AI Client not initialized (missing GROQ_API_KEY)`);
    return null;
  }
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      console.log(`   [Attempt ${attempt}/3] Sending request to Groq API (model: ${model})...`);
      const response = await client.chat.completions.create({
        model,
        temperature: 0.9,
        max_tokens: 500,
        messages: [
          { role: "system", content: "Return only JSON. No markdown. No commentary." },
          { role: "user", content: prompt }
        ]
      });
      const text = response.choices?.[0]?.message?.content || "";
      console.log(`   [Attempt ${attempt}/3] Response received: ${text.slice(0, 100)}...`);
      const parsed = extractJson(text);
      if (parsed) {
        console.log(`   ✅ JSON parsed successfully`);
        return parsed;
      }
      console.log(`   ⚠️  Could not extract JSON from response`);
      return null;
    } catch (err) {
      const status = err?.status;
      console.log(`   ❌ API Error (attempt ${attempt}/3): ${err?.message || err}`);
      if (status === 429 && attempt < 3) {
        const waitTime = attempt * 5000;
        console.log(`   ⏳ Rate limited! Waiting ${waitTime}ms before retry...`);
        await new Promise(r => setTimeout(r, waitTime));
        continue;
      }
      return null;
    }
  }
  return null;
}
 