@echo off
echo ==========================================
echo AUTONOMOUS AI CHAOS QA
echo ==========================================

if not exist .env (
  copy .env.example .env >nul
  echo.
  echo .env was created from .env.example.
  echo Open .env, paste your API key, save it, then run this file again.
  echo.
  pause
  exit /b 1
)

call npm install
call npx playwright install chromium
call npx playwright test tests/chaos.spec.js --headed

echo.
echo Report: reports\chaos-report.html
pause
