"""
AI Analyzer
-----------
Step 4 & 5 of the proposed solution ("AI Identifies Weaknesses" /
"AI Generates Reports"): aggregates the raw chaos-test results stored in
SQLite and asks a local Ollama model to produce a resilience report:
a summary, a list of concrete findings, prioritized recommendations, and a
0-100 resilience score.

Falls back to a rule-based report if Ollama is not reachable, so the app
still works end-to-end even without the LLM running.
"""
import json
import re

import requests

from backend import database as db
from backend.config import OLLAMA_URL, OLLAMA_MODEL


def _build_stats(results, recovery_summary=None):
    total = len(results)
    anomalies = [r for r in results if r["is_anomaly"]]
    by_scenario = {}
    for r in results:
        by_scenario.setdefault(r["scenario"], {"total": 0, "anomalies": 0})
        by_scenario[r["scenario"]]["total"] += 1
        if r["is_anomaly"]:
            by_scenario[r["scenario"]]["anomalies"] += 1
    stats = {
        "total_tests": total,
        "total_anomalies": len(anomalies),
        "by_scenario": by_scenario,
        "anomaly_samples": [
            {
                "scenario": r["scenario"],
                "endpoint": r["endpoint"],
                "test_case": r["test_case"],
                "status_code": r["status_code"],
                "reason": r["anomaly_reason"],
            }
            for r in anomalies[:20]
        ],
    }
    if recovery_summary:
        stats["fault_injection_recovery"] = {
            "endpoint": recovery_summary["endpoint"],
            "fault_type": recovery_summary["fault_type"],
            "outcome": recovery_summary["outcome"],
            "recovery_time_ms": recovery_summary["recovery_time_ms"],
            "total_attempts": recovery_summary["total_attempts"],
            "root_cause": recovery_summary["root_cause"],
        }
    return stats


def _build_prompt(stats):
    return f"""You are an expert Site Reliability / QA engineer reviewing results from an
automated chaos-testing run against a REST API. Below is a JSON summary of what was tested,
including (if present) a dedicated fault-injection-and-recovery timing test.

DATA:
{json.dumps(stats, indent=2)}

Respond with ONLY a valid JSON object (no markdown fences, no extra text) with exactly these keys:
- "summary": a 2-3 sentence plain-English summary of overall resilience, mentioning recovery time if a fault_injection_recovery result is present.
- "findings": an array of short strings, one per distinct weakness discovered (be specific: mention endpoint/scenario).
- "recommendations": an array of short, actionable strings for how the engineering team should fix each weakness.
- "resilience_score": a number from 0 to 100 (higher = more resilient), based on the ratio/severity of anomalies and, if present, how fast and reliably the service recovered from the injected fault.

JSON:"""


def _fallback_report(stats):
    total = stats["total_tests"] or 1
    anomalies = stats["total_anomalies"]
    score = max(0, round(100 - (anomalies / total) * 100, 1))
    findings = [f"{a['scenario']} on {a['endpoint']} ({a['test_case']}): {a['reason']}"
                for a in stats["anomaly_samples"]] or ["No anomalies detected in this run."]
    recommendations = [
        "Add input validation (4xx responses) for malformed or missing fields.",
        "Add timeout guards and circuit breakers around downstream service calls.",
        "Ensure downstream outages degrade gracefully (503 + fallback) instead of crashing.",
        "Add retry logic with backoff for transient failures.",
    ] if anomalies else ["Continue periodic chaos testing to maintain resilience."]
    return {
        "summary": f"{anomalies} of {total} chaos tests surfaced resilience issues (Ollama unavailable - rule-based summary shown).",
        "findings": findings,
        "recommendations": recommendations,
        "resilience_score": score,
    }


def _extract_json(text):
    text = text.strip()
    text = re.sub(r"^```(json)?", "", text).strip()
    text = re.sub(r"```$", "", text).strip()
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if match:
        text = match.group(0)
    return json.loads(text)


def generate_report(run_id):
    results = db.get_results(run_id)
    recovery_summary = db.get_recovery_summary(run_id)
    stats = _build_stats(results, recovery_summary)
    prompt = _build_prompt(stats)

    parsed = None
    try:
        resp = requests.post(
            OLLAMA_URL,
            json={"model": OLLAMA_MODEL, "prompt": prompt, "stream": False},
            timeout=90,
        )
        resp.raise_for_status()
        raw_text = resp.json().get("response", "")
        parsed = _extract_json(raw_text)
    except Exception:
        parsed = None

    if not parsed or "summary" not in parsed:
        parsed = _fallback_report(stats)

    parsed.setdefault("findings", [])
    parsed.setdefault("recommendations", [])
    parsed.setdefault("resilience_score", _fallback_report(stats)["resilience_score"])

    db.save_report(
        run_id,
        summary=parsed["summary"],
        findings=parsed["findings"],
        recommendations=parsed["recommendations"],
        resilience_score=float(parsed["resilience_score"]),
    )
    return db.get_report(run_id)
