const { defineConfig } = require("@playwright/test");
require("dotenv").config();

module.exports = defineConfig({
  testDir: "./tests",
  timeout: 180000,
  workers: 1,
  reporter: [["list"]],
  use: {
    headless: false,
    slowMo: 100,
    actionTimeout: Number(process.env.PLAYWRIGHT_TIMEOUT_MS || 8000),
    navigationTimeout: 15000,
    screenshot: "only-on-failure",
    trace: "retain-on-failure"
  },
  webServer: {
    command: "node server.js",
    url: "http://127.0.0.1:8080/chaos-playground/",
    timeout: 15000,
    reuseExistingServer: true
  }
});
