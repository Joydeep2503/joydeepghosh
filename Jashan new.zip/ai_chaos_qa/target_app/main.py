"""
Demo "Application Under Test" (AUT)
------------------------------------
A small, intentionally-fragile e-commerce style API used to demonstrate the
AI Chaos QA agent. It exposes normal business endpoints (products, orders,
payments) plus two "chaos hooks" that the QA agent uses to simulate a
partial outage of a downstream dependency.

Run with:  uvicorn target_app.main:app --port 9000 --reload
"""
import random
import time
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI(title="Demo Application Under Test (AUT)")

# ---------------------------------------------------------------------------
# In-memory "database" for the demo app
# ---------------------------------------------------------------------------
PRODUCTS = {
    1: {"id": 1, "name": "Wireless Mouse", "price": 19.99, "stock": 50},
    2: {"id": 2, "name": "Mechanical Keyboard", "price": 89.99, "stock": 20},
    3: {"id": 3, "name": "USB-C Hub", "price": 34.50, "stock": 0},
}
ORDERS = {}
ORDER_SEQ = 1

# Chaos state - toggled remotely by the AI Chaos QA agent
STATE = {"downstream_outage": False, "flaky_mode": False}


class OrderRequest(BaseModel):
    user_id: int
    product_id: int
    quantity: int


class PaymentRequest(BaseModel):
    order_id: int
    amount: float
    card_number: str


class OutageToggle(BaseModel):
    enable: bool


@app.get("/health")
def health():
    return {"status": "ok", "downstream_outage": STATE["downstream_outage"]}


@app.get("/products")
def list_products():
    return list(PRODUCTS.values())


@app.get("/products/{product_id}")
def get_product(product_id: int):
    product = PRODUCTS.get(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return product


def call_inventory_service(product_id: int, quantity: int):
    """Simulated downstream dependency call.
    Deliberately has NO retry / circuit breaker / fallback logic, so that the
    chaos agent's 'Partial Outage' scenario can expose the weakness.
    """
    if STATE["downstream_outage"]:
        raise HTTPException(status_code=503, detail="Inventory service unavailable")
    if STATE["flaky_mode"] and random.random() < 0.4:
        time.sleep(3.5)  # simulate a slow / hanging downstream call
    product = PRODUCTS.get(product_id)
    if product is None:
        return None
    return product["stock"] >= quantity


@app.post("/orders")
def create_order(order: OrderRequest):
    global ORDER_SEQ
    # Weakness (intentional): no validation that quantity > 0
    available = call_inventory_service(order.product_id, order.quantity)
    if available is None:
        # Weakness (intentional): unhandled KeyError -> raw 500 instead of clean 404
        product = PRODUCTS[order.product_id]
    if not available:
        raise HTTPException(status_code=409, detail="Insufficient stock")
    order_id = ORDER_SEQ
    ORDER_SEQ += 1
    ORDERS[order_id] = order.dict()
    PRODUCTS[order.product_id]["stock"] -= order.quantity
    return {"order_id": order_id, "status": "created"}


@app.get("/orders/slow")
def slow_orders():
    # Weakness (intentional): no timeout guard on a slow operation
    time.sleep(6)
    return {"orders": list(ORDERS.values())}


@app.post("/payments/charge")
def charge_payment(payment: PaymentRequest):
    if payment.order_id not in ORDERS:
        raise HTTPException(status_code=404, detail="Order not found")
    # Weakness (intentional): crashes (500) if card_number is too short / wrong type
    last4 = payment.card_number[-4:]
    if payment.amount <= 0:
        # Weakness (intentional): silently "succeeds" instead of validating amount
        pass
    return {"status": "charged", "card_last4": last4, "amount": payment.amount}


@app.post("/chaos/toggle-outage")
def toggle_outage(toggle: OutageToggle):
    """Chaos hook: simulate a partial outage of the downstream inventory service."""
    STATE["downstream_outage"] = toggle.enable
    return {"downstream_outage": STATE["downstream_outage"]}


@app.post("/chaos/toggle-flaky")
def toggle_flaky(toggle: OutageToggle):
    """Chaos hook: make the downstream dependency intermittently slow."""
    STATE["flaky_mode"] = toggle.enable
    return {"flaky_mode": STATE["flaky_mode"]}
