import { Page } from "@playwright/test";
export type ChaosSeverity =
 | "LOW"
 | "MEDIUM"
 | "HIGH"
 | "CRITICAL";
export type ChaosCategory =
 | "VALIDATION"
 | "CRASH"
 | "UI_STATE"
 | "NAVIGATION"
 | "DATA_HANDLING"
 | "ACCESSIBILITY"
 | "UNEXPECTED_BEHAVIOR"
 | "PERFORMANCE"
 | "NONE";
export interface ChaosObservation {
 title: string;
 severity: ChaosSeverity;
 category: ChaosCategory;
 isEdgeCase: boolean;
 reason: string;
 observedBehavior: string;
 expectedBehavior: string;
 confidence: number;
 evidence: string[];
 recommendation: string;
}
export interface ChaosAnalysisInput {
 action: string;
 targetId?: string;
 value?: string;
 reason?: string;
 beforeUrl?: string;
 afterUrl?: string;
 beforeTitle?: string;
 afterTitle?: string;
 bodyText?: string;
 executionError?: string;
 executionResult?: unknown;
}
function containsAny(
 text: string,
 patterns: string[]
): boolean {
 const normalized = text.toLowerCase();
 return patterns.some(
   (pattern) =>
     normalized.includes(pattern.toLowerCase())
 );
}
function calculateConfidence(
 severity: ChaosSeverity,
 evidenceCount: number
): number {
 let confidence = 50;
 if (severity === "CRITICAL") {
   confidence += 35;
 } else if (severity === "HIGH") {
   confidence += 25;
 } else if (severity === "MEDIUM") {
   confidence += 15;
 } else {
   confidence += 5;
 }
 confidence += Math.min(
   evidenceCount * 5,
   15
 );
 return Math.min(confidence, 99);
}
/**
* Analyze the result of an AI-generated action.
*
* This layer does NOT simply assume that a failed action
* is a bug.
*
* It evaluates the resulting application behavior and
* classifies whether the behavior looks like an edge case.
*/
export async function analyzeChaos(
 input: ChaosAnalysisInput
): Promise<ChaosObservation> {
 const evidence: string[] = [];
 const bodyText =
   input.bodyText || "";
 const executionError =
   input.executionError || "";
 const action =
   input.action || "unknown";
 const targetId =
   input.targetId || "unknown";
 const value =
   input.value ?? "";
 /*
  * --------------------------------------------------
  * 1. Application crash / severe execution failure
  * --------------------------------------------------
  */
 const crashDetected =
   containsAny(
     executionError,
     [
       "page crashed",
       "browser has been closed",
       "target page",
       "target closed",
       "execution context was destroyed",
       "out of memory",
     ]
   );
 if (crashDetected) {
   evidence.push(
     `Application/browser execution failure: ${executionError}`
   );
   return {
     title:
       "Application Crash or Unrecoverable Failure",
     severity:
       "CRITICAL",
     category:
       "CRASH",
        isEdgeCase:
          false,
     reason:
       "The AI-generated interaction caused an unrecoverable application or browser execution failure.",
     observedBehavior:
       executionError,
     expectedBehavior:
       "The application should handle unusual user input or interaction without crashing or destroying the active page.",
     confidence:
       calculateConfidence(
         "CRITICAL",
         evidence.length
       ),
     evidence,
     recommendation:
       "Investigate the failure stack trace and reproduce the AI-generated interaction manually. Add a regression test for the failing scenario.",
   };
 }
 /*
  * --------------------------------------------------
  * 2. Navigation failure
  * --------------------------------------------------
  */
 const navigationError =
   containsAny(
     executionError,
     [
       "net::err_",
       "navigation failed",
       "timeout",
       "timed out",
       "failed to navigate",
     ]
   );
 if (navigationError) {
   evidence.push(
     `Navigation/execution error: ${executionError}`
   );
   return {
     title:
       "Unexpected Navigation Failure",
     severity:
       "HIGH",
     category:
       "NAVIGATION",
     isEdgeCase:
       true,
     reason:
       "The application did not successfully complete the navigation or interaction requested by the autonomous agent.",
     observedBehavior:
       executionError,
     expectedBehavior:
       "The application should either complete the requested navigation or display a meaningful recoverable error state.",
     confidence:
       calculateConfidence(
         "HIGH",
         evidence.length
       ),
     evidence,
     recommendation:
       "Verify network handling, route protection, loading states, and error handling for the affected interaction.",
   };
 }
 /*
  * --------------------------------------------------
  * 3. Validation / error-message detection
  * --------------------------------------------------
  */
 const validationDetected =
   containsAny(
     bodyText,
     [
       "required",
       "please enter",
       "please select",
       "invalid",
       "must be",
       "cannot be empty",
       "field is required",
       "enter a valid",
       "minimum",
       "maximum",
     ]
   );
 /*
  * A validation message by itself is NOT automatically
  * considered a bug.
  *
  * If the application correctly rejects an unusual value,
  * this is expected behavior.
  */
 if (
   validationDetected &&
   (
     action === "fill" ||
     action === "type" ||
     action === "select"
   )
 ) {
   evidence.push(
     "Validation-related text was detected after the AI interaction."
   );
   if (
     value === "" ||
     value.trim() === ""
   ) {
     return {
       title:
         "Empty-Value Validation Boundary",
       severity:
         "LOW",
       category:
         "VALIDATION",
       isEdgeCase:
         true,
       reason:
          "The AI tested an empty value and the application correctly responded with ordinary validation behavior.",
       observedBehavior:
         "The application displayed validation-related feedback for an empty or missing value.",
       expectedBehavior:
         "The application should reject empty required input with a clear validation message without crashing or entering an invalid state.",
       confidence:
         calculateConfidence(
           "LOW",
           evidence.length
         ),
       evidence,
       recommendation:
          "Keep the validation message clear, accessible, and consistent with the field requirements.",
     };
   }
   return {
     title:
       "Boundary Input Validation",
     severity:
       "LOW",
     category:
       "VALIDATION",
     isEdgeCase:
       false,
     reason:
       "The application appears to have handled an unusual input using validation rather than entering an invalid state.",
     observedBehavior:
       "Validation feedback was displayed after the AI-generated interaction.",
     expectedBehavior:
       "Invalid input should be rejected safely with a meaningful validation message.",
     confidence:
       calculateConfidence(
         "LOW",
         evidence.length
       ),
     evidence,
     recommendation:
       "Keep this behavior covered by automated validation tests.",
   };
 }
 /*
  * --------------------------------------------------
  * 4. Empty input without validation
  * --------------------------------------------------
  */
 if (
   (
     action === "fill" ||
     action === "type"
   ) &&
   value.trim() === "" &&
   !validationDetected
 ) {
   evidence.push(
     "AI supplied an empty value."
   );
   evidence.push(
     "No obvious validation message was detected in the resulting page."
   );
   return {
     title:
       "Empty Input Accepted Without Visible Validation",
     severity:
       "MEDIUM",
     category:
       "DATA_HANDLING",
     isEdgeCase:
       true,
     reason:
       "The AI intentionally supplied an empty value and no obvious validation response was detected.",
     observedBehavior:
       "The empty value was submitted or processed without a visible validation message.",
     expectedBehavior:
       "Required fields should reject empty input or clearly indicate that the field is optional.",
     confidence:
       calculateConfidence(
         "MEDIUM",
         evidence.length
       ),
     evidence,
     recommendation:
       "Verify whether the field is actually optional. If it is required, add server-side and client-side validation.",
   };
 }
 /*
  * --------------------------------------------------
  * 5. Unexpected error messages
  * --------------------------------------------------
  */
 const unexpectedError =
   containsAny(
     bodyText,
     [
       "something went wrong",
       "internal server error",
       "unexpected error",
       "application error",
       "server error",
       "500 internal",
       "uncaught",
       "exception",
       "stack trace",
     ]
   );
 if (unexpectedError) {
   evidence.push(
     "Unexpected error-related text was detected in the application."
   );
   return {
     title:
       "Unexpected Application Error",
     severity:
       "HIGH",
     category:
       "UNEXPECTED_BEHAVIOR",
     isEdgeCase:
       true,
     reason:
       "The AI-generated interaction resulted in an unexpected application error state.",
     observedBehavior:
       "The resulting page contained an application error or exception-related message.",
     expectedBehavior:
       "The application should handle unusual interactions gracefully and provide a controlled error state.",
     confidence:
       calculateConfidence(
         "HIGH",
         evidence.length
       ),
     evidence,
     recommendation:
       "Inspect browser console errors, network responses, and server logs. Reproduce the interaction and add a regression test.",
   };
 }
 /*
  * --------------------------------------------------
  * 6. Navigation state change
  * --------------------------------------------------
  */
 if (
   input.beforeUrl &&
   input.afterUrl &&
   input.beforeUrl !== input.afterUrl
 ) {
   evidence.push(
     `URL changed from ${input.beforeUrl} to ${input.afterUrl}.`
   );
   return {
     title:
       "AI-Induced Navigation State Change",
     severity:
       "LOW",
     category:
       "NAVIGATION",
     isEdgeCase:
       false,
     reason:
       "The AI interaction caused the application to navigate to a different URL.",
     observedBehavior:
       `Application navigated from ${input.beforeUrl} to ${input.afterUrl}.`,
     expectedBehavior:
       "Navigation should occur when the selected action is expected to trigger a route or page transition.",
     confidence:
       calculateConfidence(
         "LOW",
         evidence.length
       ),
     evidence,
     recommendation:
       "Verify that the resulting route is correct and that browser history and application state remain consistent.",
   };
 }
 /*
  * --------------------------------------------------
  * 7. No obvious anomaly
  * --------------------------------------------------
  */
 return {
   title:
     "Normal Application Behavior",
   severity:
     "LOW",
   category:
     "NONE",
   isEdgeCase:
     false,
   reason:
     "The AI-generated interaction completed without an obvious crash, unexpected error, abnormal navigation, or suspicious application state.",
   observedBehavior:
     "The application remained operational after the interaction.",
   expectedBehavior:
     "The application should continue operating normally after a valid interaction.",
   confidence:
     85,
   evidence: [
     `Action executed: ${action}`,
     `Target: ${targetId}`,
   ],
   recommendation:
     "No immediate defect was identified. Continue autonomous exploration with additional boundary and unusual inputs.",
 };
}
/**
* Optional helper for future use.
*
* Takes a Playwright page and collects the visible
* application state used by the analyzer.
*/
export async function collectPageObservation(
 page: Page
): Promise<{
 url: string;
 title: string;
 bodyText: string;
}> {
 return {
   url:
     page.url(),
   title:
     await page.title().catch(
       () => ""
     ),
   bodyText:
     await page
       .locator("body")
       .innerText()
       .catch(() => ""),
 };
}