"""
Recovery Analyzer
------------------
After a fault-injection + recovery-monitoring cycle finishes
(backend/recovery_engine.py), this module asks the local Ollama model to
reason about *why* the endpoint likely degraded and *how* it recovered,
purely from the observed black-box timeline (status codes, latencies, and
the type of fault injected) - the same way an SRE would triage an incident
from monitoring data alone, without access to the target's internals.

Falls back to rule-based reasoning (pattern-matching on status codes/
timeouts) if Ollama is unreachable, so the agent still produces an answer.
"""
import json
import re

import requests

from backend.config import OLLAMA_URL, OLLAMA_MODEL


def _extract_json(text):
    text = text.strip()
    text = re.sub(r"^```(json)?", "", text).strip()
    text = re.sub(r"```$", "", text).strip()
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if match:
        text = match.group(0)
    return json.loads(text)


def _fallback_analysis(result):
    attempts = result["attempts"]
    timeouts = sum(1 for a in attempts if a["error"] == "timeout")
    server_errors = sum(1 for a in attempts if a["status"] and a["status"] >= 500 and a["status"] != 503)
    unavailable = sum(1 for a in attempts if a["status"] == 503)

    if unavailable >= max(server_errors, timeouts) and unavailable > 0:
        cause = (
            "The endpoint returned 503 Service Unavailable during the fault window, consistent with "
            "a downstream dependency (or the service itself) being temporarily taken offline."
        )
    elif timeouts > 0 and timeouts >= server_errors:
        cause = (
            "Requests timed out during the fault window, consistent with the service being overloaded "
            "or blocked (e.g. thread/connection exhaustion) rather than fully down."
        )
    elif server_errors > 0:
        cause = (
            "The endpoint returned 5xx server errors during the fault window, consistent with an "
            "unhandled exception or crash under the injected fault/load."
        )
    else:
        cause = (
            "The endpoint did not show clear failure signals during the fault window - it may have "
            "absorbed the injected load/fault without measurable degradation."
        )

    if result["outcome"] == "recovered":
        recovery = (
            f"After the fault was cleared, the endpoint returned to healthy responses within "
            f"{result['recovery_time_ms'] / 1000:.1f}s across {result['total_attempts']} poll attempt(s) - "
            "consistent with a transient fault that resolved once the triggering condition subsided."
        )
    else:
        recovery = (
            f"The endpoint had not returned to a healthy state after {result['total_attempts']} poll "
            "attempts within the monitoring window - this suggests a persistent failure (e.g. a crash "
            "requiring a restart, or a stuck downstream dependency) rather than a transient one."
        )

    recommendations = [
        "Add or verify a circuit breaker so repeated failures degrade fast instead of hanging.",
        "Add client-side retries with exponential backoff for transient 5xx/timeout responses.",
        "Add automated health checks and restart/self-healing policies for cases that don't self-recover.",
    ]
    return {"root_cause": cause, "recovery_explanation": recovery, "recommendations": recommendations}


def analyze_recovery(result):
    """`result` is the dict returned by recovery_engine.monitor_recovery():
    endpoint, fault_type, outcome, recovery_time_ms, total_attempts,
    attempts[], baseline. Returns {root_cause, recovery_explanation, recommendations}."""
    prompt = f"""You are an SRE analyzing a black-box fault-injection test against a REST API endpoint.
You only have the observed HTTP behavior below (no server logs or source code access).

ENDPOINT: {result['endpoint']}
FAULT INJECTED: {result['fault_type']}
BASELINE (before fault): {json.dumps(result['baseline'])}
OUTCOME: {result['outcome']}
RECOVERY TIME: {f"{result['recovery_time_ms']:.0f}ms" if result.get('recovery_time_ms') else "did not recover within the monitoring window"}
POLL ATTEMPTS (chronological, one per probe after the fault was cleared):
{json.dumps(result['attempts'], indent=2)}

Respond with ONLY a valid JSON object (no markdown fences, no extra text) with exactly these keys:
- "root_cause": 1-3 sentences inferring the most likely reason the endpoint degraded, based on the status-code/timeout/latency pattern.
- "recovery_explanation": 1-3 sentences on how/whether it recovered, based on the timeline.
- "recommendations": array of short, actionable resilience improvements.

JSON:"""

    try:
        resp = requests.post(
            OLLAMA_URL, json={"model": OLLAMA_MODEL, "prompt": prompt, "stream": False}, timeout=90
        )
        resp.raise_for_status()
        raw = resp.json().get("response", "")
        parsed = _extract_json(raw)
        if not all(k in parsed for k in ("root_cause", "recovery_explanation", "recommendations")):
            raise ValueError("Model response missing required keys")
        return parsed
    except Exception:
        return _fallback_analysis(result)
